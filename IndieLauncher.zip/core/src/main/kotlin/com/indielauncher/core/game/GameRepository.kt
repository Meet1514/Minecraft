package com.indielauncher.core.game

import com.indielauncher.core.auth.AccountStore
import com.indielauncher.core.download.DownloadManager
import com.indielauncher.core.launch.Profile
import com.indielauncher.core.mods.ContentManager
import com.indielauncher.core.mods.ModManager
import com.indielauncher.core.mods.ModrinthApi
import com.indielauncher.core.mods.CurseForgeApi
import com.indielauncher.core.repository.ContentRepository
import com.indielauncher.core.runtime.RuntimeManager
import com.indielauncher.core.runtime.GameProcess
import com.indielauncher.core.runtime.RendererBackend
import com.indielauncher.core.runtime.RendererRegistry
import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.Os
import com.indielauncher.core.util.PreferencesStore
import java.io.File

/**
 * 游戏仓库。聚合所有核心服务，是 Android UI 层与底层逻辑的唯一入口。
 *
 * 对应调研报告中"领域层"的定义：账号、版本、下载、安装、内容管理、
 * 启动编排都通过这里暴露，UI 不直接接触底层实现。
 */
class GameRepository(
    val rootDir: File,
    val librariesDir: File,
    val assetsDir: File,
    val nativesDir: File,
    val runtimeDir: File,
    val renderersDir: File = File(rootDir, "renderers"),
    val profilesDir: File = File(rootDir, "profiles"),
    val preferences: PreferencesStore
) {

    val http: HttpClient = HttpClient()
    val downloader: DownloadManager = DownloadManager(http)

    val manifest: VersionManifest = VersionManifest(http)
    private val resolver: VersionResolver by lazy { VersionResolver(File(rootDir, "versions"), manifest) }
    val installer: GameInstaller by lazy {
        GameInstaller(
            versionsDir = File(rootDir, "versions"),
            librariesDir = librariesDir,
            assetsDir = assetsDir,
            nativesRootDir = nativesDir,
            downloader = downloader,
            http = http
        )
    }

    val accounts: AccountStore by lazy {
        AccountStore(File(rootDir, "accounts.json"))
    }

    val runtime: RuntimeManager by lazy {
        RuntimeManager(runtimeDir, downloader, http)
    }

    val modrinth: ModrinthApi by lazy { ModrinthApi(http) }
    val curseForge: CurseForgeApi? by lazy {
        val key = preferences.getString(PreferencesStore.KEY_CURSEFORGE_API_KEY, "")
        if (key.isNotEmpty()) CurseForgeApi(key, http) else null
    }
    val content: ContentRepository by lazy {
        ContentRepository(modrinth, curseForge)
    }

    // Profile 管理
    fun listProfiles(): List<Profile> {
        if (!profilesDir.exists()) return emptyList()
        return profilesDir.listFiles { f -> f.extension == "json" }
            ?.mapNotNull { runCatching { Profile.load(it) }.getOrNull() }
            ?.toList() ?: emptyList()
    }

    fun saveProfile(profile: Profile) {
        profile.save(profilesDir)
    }

    fun deleteProfile(id: String) {
        File(profilesDir, "$id.json").delete()
        File(rootDir, "games/$id").deleteRecursively()
    }

    /** 创建新 profile 并自动安装对应版本。 */
    fun createProfile(
        name: String,
        versionId: String,
        loader: String? = null,
        loaderVersion: String? = null
    ): Profile {
        val id = name.replace(Regex("[^a-zA-Z0-9_-]"), "_").lowercase() +
            "-" + System.currentTimeMillis().toString(36)
        val gameDir = File(rootDir, "games/$id")
        gameDir.mkdirs()

        val profile = Profile(
            id = id,
            name = name,
            gameDir = gameDir,
            versionId = versionId,
            loader = loader,
            loaderVersion = loaderVersion,
            runtimeId = preferences.getString(PreferencesStore.KEY_DEFAULT_RUNTIME, ""),
            rendererId = preferences.getString(PreferencesStore.KEY_DEFAULT_RENDERER, "zink"),
            memoryMb = preferences.getInt(PreferencesStore.KEY_DEFAULT_MEMORY_MB, 2048)
        )
        saveProfile(profile)
        return profile
    }

    /** 为 profile 准备 Mod 管理器。 */
    fun modManager(profileId: String): ModManager {
        val modsDir = File(rootDir, "games/$profileId/mods")
        return ModManager(modsDir, downloader)
    }

    fun resourcePackManager(profileId: String): ContentManager {
        val dir = File(rootDir, "games/$profileId/resourcepacks")
        return ContentManager(dir)
    }

    fun shaderPackManager(profileId: String): ContentManager {
        val dir = File(rootDir, "games/$profileId/shaderpacks")
        return ContentManager(dir)
    }

    /** 启动游戏。 */
    fun launch(profile: Profile, account: com.indielauncher.core.auth.Account): GameProcess {
        // 1. 解析版本元数据（含 inheritsFrom 合并）
        val meta = resolver.resolve(profile.versionId)

        // 2. 构建启动计划
        val javaBinary = File(runtimeDir, "bin/java")
        val planBuilder = com.indielauncher.core.launch.LaunchPlanBuilder(
            gameDir = profile.gameDir,
            assetsDir = assetsDir,
            librariesDir = librariesDir,
            nativesRootDir = nativesDir,
            runtimeDir = runtimeDir,
            renderersDir = renderersDir,
            runtimeJavaBinary = javaBinary,
            abi = Os.androidAbi
        )
        val plan = planBuilder.build(meta, account, profile)

        // 3. 创建进程
        val gp = GameProcess(plan)
        gp.start()
        return gp
    }
}
