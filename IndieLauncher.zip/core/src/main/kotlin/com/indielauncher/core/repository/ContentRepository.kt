package com.indielauncher.core.repository

import com.indielauncher.core.mods.CurseForgeApi
import com.indielauncher.core.mods.ModrinthApi
import com.indielauncher.core.mods.ModLoader
import com.indielauncher.core.mods.ModSource

/**
 * 统一内容仓库。聚合 Modrinth + CurseForge，对外提供统一的搜索接口。
 *
 * 两个平台的结果会合并去重（按 Mod 名称相似度）。
 */
class ContentRepository(
    private val modrinth: ModrinthApi,
    private val curseForge: CurseForgeApi? = null
) {

    sealed class ContentItem {
        data class ModrinthItem(
            val id: String,
            val title: String,
            val description: String,
            val author: String,
            val downloads: Long,
            val iconUrl: String,
            val versions: List<String>,
            val categories: List<String>
        ) : ContentItem()

        data class CurseForgeItem(
            val id: Int,
            val name: String,
            val summary: String,
            val authors: List<String>,
            val downloads: Long,
            val logoUrl: String,
            val gameVersions: List<String>
        ) : ContentItem()
    }

    /** 搜索 Mod。返回统一包装的结果。 */
    fun searchMods(
        query: String = "",
        loader: ModLoader? = null,
        gameVersion: String? = null,
        limit: Int = 20
    ): List<ContentItem> {
        val results = mutableListOf<ContentItem>()

        // Modrinth
        try {
            val loaderStr = when (loader) {
                ModLoader.FABRIC -> "fabric"
                ModLoader.FORGE -> "forge"
                ModLoader.QUILT -> "quilt"
                else -> null
            }
            val mr = modrinth.search(query, loaderStr, gameVersion, limit = limit)
            results.addAll(mr.hits.map {
                ContentItem.ModrinthItem(
                    id = it.id,
                    title = it.title,
                    description = it.description,
                    author = it.author,
                    downloads = it.downloads,
                    iconUrl = it.iconUrl,
                    versions = it.versions,
                    categories = it.displayCategories
                )
            })
        } catch (t: Throwable) {
            // Modrinth 失败不影响 CurseForge
        }

        // CurseForge
        if (curseForge != null) {
            try {
                val loaderType = when (loader) {
                    ModLoader.FABRIC -> CurseForgeApi.LOADER_FABRIC
                    ModLoader.FORGE -> CurseForgeApi.LOADER_FORGE
                    ModLoader.QUILT -> CurseForgeApi.LOADER_QUILT
                    else -> null
                }
                val cf = curseForge.search(query, loaderType = loaderType, gameVersion = gameVersion, pageSize = limit)
                results.addAll(cf.mods.map {
                    ContentItem.CurseForgeItem(
                        id = it.id,
                        name = it.name,
                        summary = it.summary,
                        authors = it.authors,
                        downloads = it.downloadCount,
                        logoUrl = it.logoUrl,
                        gameVersions = it.latestFiles.firstOrNull()?.gameVersions ?: emptyList()
                    )
                })
            } catch (t: Throwable) {
                // ignore
            }
        }

        return results
    }
}
