package com.indielauncher.core.util

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 轻量日志工具。同时输出到标准输出与本地文件，
 * 便于崩溃后排查（调研报告强调"日志是诊断闭环"）。
 */
object Logger {

    enum class Level { DEBUG, INFO, WARN, ERROR }

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
    private var logFile: File? = null
    private var minLevel: Level = Level.DEBUG

    fun configure(logDir: File, level: Level = Level.DEBUG) {
        this.logFile = File(logDir, "launcher.log")
        this.minLevel = level
        logDir.mkdirs()
    }

    fun d(tag: String, msg: String) = log(Level.DEBUG, tag, msg)
    fun i(tag: String, msg: String) = log(Level.INFO, tag, msg)
    fun w(tag: String, msg: String) = log(Level.WARN, tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) {
        log(Level.ERROR, tag, msg)
        t?.let { log(Level.ERROR, tag, Log.getStackTraceString(it)) }
    }

    private fun log(level: Level, tag: String, msg: String) {
        if (level.ordinal < minLevel.ordinal) return
        val line = "${dateFormat.format(Date())} ${level.name[0]}/$tag: $msg"
        println(line)
        try {
            logFile?.appendText(line + "\n")
        } catch (_: Throwable) { /* ignore */ }
    }

    fun readRecent(limitLines: Int = 500): List<String> {
        val f = logFile ?: return emptyList()
        if (!f.exists()) return emptyList()
        return f.readLines().takeLast(limitLines)
    }
}
