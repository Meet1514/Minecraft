package com.indielauncher.core.runtime

import java.io.File

/**
 * 渲染后端抽象。Zink / GL4ES / 直接 EGL 各有不同的
 * JVM 属性、LD_LIBRARY_PATH 与参数要求。
 *
 * 调研报告强调：渲染选择应被设计为策略，而不是编译期常量。
 */
interface RendererBackend {
    val id: String
    val displayName: String

    /** 该后端需要的 JVM 系统属性 */
    fun requiredJvmProperties(abi: String): List<Pair<String, String>>

    /** 需要加入 LD_LIBRARY_PATH 的目录 */
    fun requiredLibraryPaths(abi: String, renderersDir: File): List<String>

    /** 额外 JVM 参数 */
    fun requiredJvmArgs(): List<String>

    /** 环境变量（启动前设置） */
    fun requiredEnvironment(abi: String, runtimeDir: File, nativesDir: File): Map<String, String>
}

/** Zink（OpenGL over Vulkan via Mesa） */
class ZinkBackend : RendererBackend {
    override val id: String = "zink"
    override val displayName: String = "Zink (Mesa Vulkan)"

    override fun requiredJvmProperties(abi: String): List<Pair<String, String>> = listOf(
        "org.lwjgl.opengl.libname" to "libGL.so"
    )

    override fun requiredLibraryPaths(abi: String, renderersDir: File): List<String> {
        val dir = File(renderersDir, "zink/$abi")
        return if (dir.exists()) listOf(dir.absolutePath) else emptyList()
    }

    override fun requiredJvmArgs(): List<String> = listOf(
        "-Dorg.lwjgl.opengl.Display.autoFocus=true"
    )

    override fun requiredEnvironment(abi: String, runtimeDir: File, nativesDir: File): Map<String, String> = mapOf(
        "LIBGL_DRIVERS_PATH" to File(renderersDir, "zink/$abi").absolutePath,
        "MESA_GL_VERSION_OVERRIDE" to "4.3",
        "MESA_GLSL_VERSION_OVERRIDE" to "430"
    )
}

/** GL4ES 后端（兼容旧 OpenGL ES 设备） */
class Gl4esBackend : RendererBackend {
    override val id: String = "gl4es"
    override val displayName: String = "GL4ES"

    override fun requiredJvmProperties(abi: String): List<Pair<String, String>> = listOf(
        "org.lwjgl.opengl.libname" to "libGL.so"
    )

    override fun requiredLibraryPaths(abi: String, renderersDir: File): List<String> {
        val dir = File(renderersDir, "gl4es/$abi")
        return if (dir.exists()) listOf(dir.absolutePath) else emptyList()
    }

    override fun requiredJvmArgs(): List<String> = emptyList()

    override fun requiredEnvironment(abi: String, runtimeDir: File, nativesDir: File): Map<String, String> = mapOf(
        "LIBGL_DRIVERS_PATH" to File(renderersDir, "gl4es/$abi").absolutePath
    )
}

/** 直接 EGL / OpenGL ES 后端 */
class EglBackend : RendererBackend {
    override val id: String = "egl"
    override val displayName: String = "EGL / OpenGL ES"

    override fun requiredJvmProperties(abi: String): List<Pair<String, String>> = listOf(
        "org.lwjgl.opengl.libname" to "libGLESv2.so"
    )

    override fun requiredLibraryPaths(abi: String, renderersDir: File): List<String> = emptyList()

    override fun requiredJvmArgs(): List<String> = emptyList()

    override fun requiredEnvironment(abi: String, runtimeDir: File, nativesDir: File): Map<String, String> = emptyMap()
}

object RendererRegistry {
    val all: List<RendererBackend> = listOf(
        ZinkBackend(), Gl4esBackend(), EglBackend()
    )

    fun byId(id: String): RendererBackend =
        all.firstOrNull { it.id == id } ?: all.first()
}
