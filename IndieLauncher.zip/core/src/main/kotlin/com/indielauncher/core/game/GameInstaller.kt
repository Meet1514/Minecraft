package com.indielauncher.core.game

import com.indielauncher.core.download.DownloadManager
import com.indielauncher.core.download.DownloadTask
import com.indielauncher.core.util.Hash
import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.Os
import java.io.File
import java.util.zip.ZipFile

/**
 * 游戏安装器。负责把一个版本的全部文件下载到本地。
 *
 * 流程：
 *   1. 下载 version.json（如果本地没有）
 *   2. 解析元数据，收集 client.jar + 所有 libraries + natives + asset index
 *   3. 下载客户端 jar
 *   4. 下载所有适用的依赖库
 *   5. 解压 natives 到版本专属目录
 *   6. 下载 assets index，再下载所有资源对象
 *   7. 下载 logging config
 */
class GameInstaller(
    private val versionsDir: File,
    private val librariesDir: File,
    private val assetsDir: File,
    private val nativesRootDir: File,
    private val downloader: DownloadManager,
    private val http: HttpClient = HttpClient()
) {

    data class InstallPlan(
        val tasks: List<DownloadTask>,
        val versionId: String,
        val clientJar: File,
        val nativesDir: File
    )

    /** 生成安装计划（收集所有需要下载的文件），不立即执行。 */
    fun plan(versionId: String, abi: String = Os.androidAbi): InstallPlan {
        val resolver = VersionResolver(versionsDir, VersionManifest(http))
        val meta = resolver.resolve(versionId)

        val tasks = mutableListOf<DownloadTask>()

        // 1. 保存解析后的 version.json 到本地
        val versionDir = File(versionsDir, versionId)
        versionDir.mkdirs()
        val versionJsonFile = File(versionDir, "$versionId.json")
        if (!versionJsonFile.exists()) {
            versionJsonFile.writeText(serializeVersionMeta(meta))
        }

        // 2. 客户端 jar
        val clientJar = File(versionDir, "$versionId.jar")
        val client = meta.downloads.client
        if (client != null) {
            tasks.add(
                DownloadTask(
                    url = client.url,
                    dest = clientJar,
                    expectedSha1 = client.sha1,
                    size = client.size,
                    tag = "client"
                )
            )
        }

        // 3. 依赖库
        for (lib in meta.libraries) {
            if (!lib.applies()) continue
            val local = File(librariesDir, lib.localPath())
            tasks.add(
                DownloadTask(
                    url = lib.downloadUrl(),
                    dest = local,
                    expectedSha1 = lib.expectedSha1(),
                    size = lib.size(),
                    tag = "library"
                )
            )

            // 4. natives
            val classifier = lib.nativeClassifier()
            if (classifier != null) {
                val nativeUrl = lib.url + lib.mavenPath().replace(
                    Regex("""\.jar$"""),
                    "-$classifier.jar"
                )
                // natives 下载后需要解压，这里只下载
                val nativeDest = File(nativesRootDir, "$versionId/$abi/${lib.name.replace(':', '-')}-$classifier.jar")
                tasks.add(
                    DownloadTask(
                        url = nativeUrl,
                        dest = nativeDest,
                        tag = "native"
                    )
                )
            }
        }

        // 5. asset index
        val nativesDir = File(nativesRootDir, "$versionId/$abi")
        nativesDir.mkdirs()

        return InstallPlan(
            tasks = tasks,
            versionId = versionId,
            clientJar = clientJar,
            nativesDir = nativesDir
        )
    }

    /** 执行安装计划。返回是否全部成功。 */
    fun install(plan: InstallPlan): Boolean {
        if (plan.tasks.isEmpty()) return true
        downloader.submitAll(plan.tasks)

        // 等待完成
        while (!downloader.isAllCompleted()) {
            Thread.sleep(100)
        }

        if (downloader.hasFailures()) return false

        // 解压所有 natives
        extractNatives(plan)
        return true
    }

    private fun extractNatives(plan: InstallPlan) {
        plan.nativesDir.mkdirs()
        val nativeFiles = plan.tasks.filter { it.tag == "native" && it.state == DownloadTask.TaskState.COMPLETED }
        for (nf in nativeFiles) {
            extractSelective(nf.dest, plan.nativesDir)
        }
    }

    /** 选择性解压 natives，跳过版本自带的 GL/OpenAL 相关 so（由 runtime-ffi 提供）。 */
    private fun extractSelective(zip: File, destDir: File) {
        if (!zip.exists()) return
        ZipFile(zip).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                if (entry.isDirectory) continue
                val name = entry.name

                // 跳过 META-INF 与版本自带 GL/AL 库
                if (name.startsWith("META-INF/")) continue
                if (isSystemLib(name)) continue

                val outFile = File(destDir, File(name).name)
                outFile.parentFile?.mkdirs()
                zf.getInputStream(entry).use { input ->
                    outFile.outputStream().use { input.copyTo(it) }
                }
            }
        }
    }

    private fun isSystemLib(name: String): Boolean {
        val lower = name.lowercase()
        return lower.contains("libjvm") ||
            lower.contains("libverify") ||
            lower.contains("libjava") ||
            lower.contains("libawt") ||
            lower.contains("liblwjgl") ||
            lower.contains("libglfw") ||
            lower.contains("libopenal") ||
            lower.contains("libgl") ||
            lower.contains("libegl")
    }

    /** 下载 asset index 并提取全部资源对象 URL。 */
    fun downloadAssets(meta: VersionMeta): List<DownloadTask> {
        val index = meta.assetIndex ?: return emptyList()
        val indexPath = File(assetsDir, "indexes/${index.id}.json")

        // 下载 index
        if (!indexPath.exists()) {
            indexPath.parentFile?.mkdirs()
            http.download(index.url, indexPath, expectedSha1 = index.sha1)
        }

        // 解析 index，收集 objects
        val json = JsonParser.parse(indexPath.readText()).asObject()
        val objects = json.optObject("objects") ?: return emptyList()
        val tasks = mutableListOf<DownloadTask>()
        for ((_, value) in objects.entries) {
            if (value !is JsonObject) continue
            val hash = value.optString("hash")
            if (hash.isEmpty()) continue
            val size = value.optLong("size")
            val sub = hash.take(2)
            val url = "https://resources.download.minecraft.net/$sub/$hash"
            val dest = File(assetsDir, "objects/$sub/$hash")
            if (dest.exists() && dest.length() == size) continue
            tasks.add(
                DownloadTask(
                    url = url,
                    dest = dest,
                    expectedSha1 = hash,
                    size = size,
                    tag = "asset"
                )
            )
        }
        return tasks
    }

    private fun serializeVersionMeta(meta: VersionMeta): String {
        // 由 VersionResolver 重新拉取原始文本更稳妥
        val manifest = VersionManifest(http)
        val ref = manifest.findVersion(meta.id) ?: return "{}"
        return http.downloadText(ref.url)
    }
}
