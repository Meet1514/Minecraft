package com.indielauncher.core.launch

import com.indielauncher.core.auth.Account
import com.indielauncher.core.game.VersionMeta
import com.indielauncher.core.runtime.RendererBackend
import com.indielauncher.core.runtime.RendererRegistry
import com.indielauncher.core.util.Os
import java.io.File

/**
 * 启动计划。把所有可变部分（账号、版本、运行时、渲染后端、配置）
 * 拼装成一个可执行的命令。
 *
 * 参考 FCL / Pojav 的启动参数构造逻辑，但全部自研实现。
 */
class LaunchPlanBuilder(
    private val gameDir: File,
    private val assetsDir: File,
    private val librariesDir: File,
    private val nativesRootDir: File,
    private val runtimeDir: File,
    private val renderersDir: File,
    private val runtimeJavaBinary: File,
    private val abi: String
) {

    data class LaunchPlan(
        val executable: String,
        val arguments: List<String>,
        val environment: Map<String, String>,
        val workingDirectory: File,
        val logFile: File,
        val versionId: String
    )

    fun build(
        meta: VersionMeta,
        account: Account,
        profile: Profile
    ): LaunchPlan {
        val nativesDir = File(nativesRootDir, "${profile.versionId}/$abi")
        val renderer = RendererRegistry.byId(profile.rendererId)
        val args = mutableListOf<String>()

        // === JVM 参数 ===

        // 内存
        args.add("-Xms${profile.memoryMb / 2}m")
        args.add("-Xmx${profile.memoryMb}m")

        // 基础属性
        args.add("-Djava.library.path=${nativesDir.absolutePath}")
        args.add("-Djna.boot.library.path=${nativesDir.absolutePath}")
        args.add("-Dorg.lwjgl.librarypath=${nativesDir.absolutePath}")
        args.add("-Duser.home=${gameDir.parentFile?.absolutePath ?: gameDir.absolutePath}")
        args.add("-Duser.language=zh")
        args.add("-Duser.country=CN")
        args.add("-Dfile.encoding=UTF-8")

        // 渲染后端属性
        for ((k, v) in renderer.requiredJvmProperties(abi)) {
            args.add("-D$k=$v")
        }

        // 渲染后端额外参数
        args.addAll(renderer.requiredJvmArgs())

        // JVM 参数模板（新版 arguments.jvm）
        if (meta.arguments != null) {
            for (arg in meta.arguments.jvm) {
                when (arg) {
                    is VersionMeta.Arg.StringArg -> args.add(arg.value)
                    is VersionMeta.Arg.RuleArg -> {
                        // 检查规则是否匹配
                        val matches = arg.rules.isEmpty() || arg.rules.all { it.matches() }
                        if (matches) {
                            when (val v = arg.value) {
                                is String -> args.add(v)
                                is List<*> -> v.forEach { if (it is String) args.add(it) }
                                else -> args.add(v.toString())
                            }
                        }
                    }
                }
            }
        }

        // 用户自定义 JVM 参数
        args.addAll(profile.javaArgs)

        // === 主类 ===
        args.add(meta.mainClass)

        // === 游戏参数 ===

        val classpath = buildClasspath(meta, profile.versionId)
        val features = mapOf<String, Boolean>()

        // quickPlay 等现代参数
        val gameArgsTemplate = if (meta.arguments != null) {
            meta.arguments.game.mapNotNull { arg ->
                when (arg) {
                    is VersionMeta.Arg.StringArg -> arg.value
                    is VersionMeta.Arg.RuleArg -> {
                        val matches = arg.rules.isEmpty() || arg.rules.all { it.matches() }
                        if (!matches) null
                        else when (val v = arg.value) {
                            is String -> v
                            is List<*> -> v.joinToString(" ") { it.toString() }
                            else -> v.toString()
                        }
                    }
                }
            }
        } else {
            meta.minecraftArguments?.split(' ') ?: emptyList()
        }

        // 替换变量
        val gameArgs = gameArgsTemplate.map { token ->
            when {
                token == "\${auth_player_name}" -> account.username
                token == "\${auth_access_token}" -> if (account.isOffline()) "0" else (account as? com.indielauncher.core.auth.MicrosoftAccount)?.accessToken ?: "0"
                token == "\${auth_uuid}" -> account.uuid.toString().replace("-", "")
                token == "\${auth_xuid}" -> "0"
                token == "\${user_properties}" -> "{}"
                token == "\${user_type}" -> if (account.isOffline()) "legacy" else "msa"
                token == "\${version_name}" -> profile.versionId
                token == "\${version_type}" -> meta.type
                token == "\${game_directory}" -> gameDir.absolutePath
                token == "\${assets_root}" -> assetsDir.absolutePath
                token == "\${assets_index_name}" -> meta.assets
                token == "\${library_directory}" -> librariesDir.absolutePath
                token == "\${classpath}" -> classpath
                token == "\${classpath_separator}" -> File.pathSeparator
                token == "\${natives_directory}" -> nativesDir.absolutePath
                token == "\${launcher_name}" -> "IndieLauncher"
                token == "\${launcher_version}" -> "0.1.0"
                token.startsWith("\${") && token.endsWith("}") -> {
                    // 未知变量，尝试从 features 取值
                    val key = token.substring(2, token.length - 1)
                    features[key]?.toString() ?: token
                }
                else -> token
            }
        }

        args.addAll(gameArgs)
        args.addAll(profile.gameArgs)

        // === 环境变量 ===
        val env = mutableMapOf<String, String>()
        env["JAVA_HOME"] = runtimeDir.absolutePath
        env["PATH"] = "${File(runtimeDir, "bin").absolutePath}:${System.getenv("PATH") ?: ""}"
        env["LD_LIBRARY_PATH"] = buildLibraryPath(nativesDir, renderer)
        env.putAll(renderer.requiredEnvironment(abi, runtimeDir, nativesDir))

        // 日志文件
        val logFile = File(gameDir, "logs/latest.log")
        logFile.parentFile?.mkdirs()

        return LaunchPlan(
            executable = runtimeJavaBinary.absolutePath,
            arguments = args,
            environment = env,
            workingDirectory = gameDir,
            logFile = logFile,
            versionId = profile.versionId
        )
    }

    private fun buildClasspath(meta: VersionMeta, versionId: String): String {
        val paths = mutableListOf<String>()
        // 客户端 jar
        paths.add(File(gameDir, "versions/$versionId/$versionId.jar").absolutePath)
        // 依赖库
        for (lib in meta.libraries) {
            if (!lib.applies()) continue
            paths.add(File(librariesDir, lib.localPath()).absolutePath)
        }
        return paths.joinToString(File.pathSeparator)
    }

    private fun buildLibraryPath(nativesDir: File, renderer: RendererBackend): String {
        val parts = mutableListOf<String>(
            nativesDir.absolutePath,
            File(runtimeDir, "lib").absolutePath,
            File(runtimeDir, "lib/server").absolutePath
        )
        parts.addAll(renderer.requiredLibraryPaths(abi, renderersDir))
        return parts.joinToString(":")
    }
}
