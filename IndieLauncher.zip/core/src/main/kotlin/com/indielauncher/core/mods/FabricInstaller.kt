package com.indielauncher.core.mods

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.Logger
import java.io.File

/**
 * Fabric Loader 安装器。
 *
 * 安装方式：下载官方 fabric-installer.jar，以 headless 模式运行，
 * 让 installer 生成新的 version JSON（loader 版本 + 原版 inheritsFrom）。
 *
 * 官方 meta：https://meta.fabricmc.net/v2/versions
 * 官方 installer：https://maven.fabricmc.net/net/fabricmc/fabric-installer/
 */
class FabricInstaller(
    private val versionsDir: File,
    private val librariesDir: File,
    private val javaBinary: String = "java",
    private val http: HttpClient = HttpClient()
) {

    /** 获取所有可用的 loader 版本。 */
    fun fetchLoaderVersions(): List<FabricVersion> {
        val text = http.downloadText("$FABRIC_META/versions/loader")
        val arr = JsonParser.parse(text)
        if (arr !is com.indielauncher.core.util.JsonArray) return emptyList()
        return arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map {
                FabricVersion(
                    version = it.optString("version"),
                    stable = it.optBoolean("stable")
                )
            }.toList()
    }

    /** 获取所有可用的游戏版本（Fabric 支持的 MC 版本）。 */
    fun fetchGameVersions(): List<FabricGameVersion> {
        val text = http.downloadText("$FABRIC_META/versions/game")
        val arr = JsonParser.parse(text)
        if (arr !is com.indielauncher.core.util.JsonArray) return emptyList()
        return arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map {
                FabricGameVersion(
                    version = it.optString("version"),
                    stable = it.optBoolean("stable")
                )
            }.toList()
    }

    /**
     * 安装 Fabric loader 到指定原版之上。
     * 生成新版本 id：fabric-loader-<loaderVersion>-<mcVersion>
     */
    fun install(mcVersion: String, loaderVersion: String? = null): String {
        val loader = loaderVersion ?: fetchLoaderVersions().firstOrNull()?.version
            ?: throw IllegalStateException("无法获取 Fabric loader 版本")

        val newVersionId = "fabric-loader-$loader-$mcVersion"
        val targetDir = File(versionsDir, newVersionId)
        targetDir.mkdirs()

        // 下载 installer
        val installerMeta = fetchLatestInstaller()
        val installerJar = File(targetDir, "fabric-installer.jar")
        http.download(
            url = installerMeta.url,
            dest = installerJar,
            expectedSha1 = installerMeta.sha1
        )

        // 调用 installer headless 模式生成 version JSON
        // 命令：java -jar fabric-installer.jar client -dir <gameDir> -mcversion <mc> -loader <loader> -noprofile
        val pb = ProcessBuilder(
            javaBinary, "-jar", installerJar.absolutePath,
            "client",
            "-dir", targetDir.parentFile.absolutePath,
            "-mcversion", mcVersion,
            "-loader", loader,
            "-noprofile"
        )
        pb.directory(targetDir)
        Logger.i("Fabric", "运行 installer: ${pb.command().joinToString(" ")}")
        val process = pb.start()
        val rc = process.waitFor()
        if (rc != 0) {
            val err = process.errorStream.bufferedReader().readText()
            throw IllegalStateException("Fabric installer 失败 (exit=$rc): $err")
        }

        // installer 会生成 <mcVersion>.json，重命名为 <newVersionId>.json
        val generated = File(versionsDir, "$mcVersion/$mcVersion.json")
        val target = File(targetDir, "$newVersionId.json")
        if (generated.exists()) {
            generated.copyTo(target, overwrite = true)
        }

        return newVersionId
    }

    private fun fetchLatestInstaller(): FabricArtifact {
        val text = http.downloadText("$FABRIC_MAVEN/net/fabricmc/fabric-installer/maven-metadata.xml")
        // 简单解析 maven-metadata 的 latest 版本
        val latest = Regex("""<latest>([^<]+)</latest>""").find(text)?.groupValues?.get(1)
            ?: throw IllegalStateException("无法解析 fabric-installer 最新版本")
        val metaText = http.downloadText("$FABRIC_META/versions/installer/$latest")
        val json = JsonParser.parse(metaText).asObject()
        val maven = json.optString("maven")
        val sha1 = json.optString("sha1")
        return FabricArtifact(version = latest, url = "$FABRIC_MAVEN/$maven", sha1 = sha1)
    }

    data class FabricVersion(val version: String, val stable: Boolean)
    data class FabricGameVersion(val version: String, val stable: Boolean)
    data class FabricArtifact(val version: String, val url: String, val sha1: String)

    companion object {
        const val FABRIC_META = "https://meta.fabricmc.net/v2"
        const val FABRIC_MAVEN = "https://maven.fabricmc.net/net/fabricmc/fabric-installer"
    }
}
