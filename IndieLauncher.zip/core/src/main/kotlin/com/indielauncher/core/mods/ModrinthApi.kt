package com.indielauncher.core.mods

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonArray
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser

/**
 * Modrinth API 客户端。
 *
 * API 文档：https://docs.modrinth.com/api-spec/
 * 公共接口，无需 API Key（搜索与版本查询）。
 */
class ModrinthApi(private val http: HttpClient = HttpClient()) {

    /** 搜索 Mod。 */
    fun search(
        query: String = "",
        loader: String? = null,      // fabric / forge / quilt
        gameVersion: String? = null, // 1.21.4 等
        offset: Int = 0,
        limit: Int = 20
    ): SearchResult {
        val params = mutableListOf<String>()
        if (query.isNotBlank()) params.add("query=${encode(query)}")
        params.add("offset=$offset")
        params.add("limit=$limit")
        params.add("index=relevance")
        if (loader != null) params.add("facets=[[\"categories:$loader\"]]")
        if (gameVersion != null) params.add("facets=[[\"versions:$gameVersion\"]]")

        val url = "$BASE_URL/search?" + params.joinToString("&")
        val text = http.downloadText(url)
        return parseSearchResult(text)
    }

    /** 获取某个项目的最新版本（用于依赖解析）。 */
    fun getVersions(projectId: String, loader: String? = null, gameVersion: String? = null): List<ModVersion> {
        val params = mutableListOf<String>()
        if (loader != null) params.add("loaders=[\"$loader\"]")
        if (gameVersion != null) params.add("game_versions=[\"$gameVersion\"]")
        val qs = if (params.isEmpty()) "" else "?" + params.joinToString("&")
        val url = "$BASE_URL/project/$projectId/version$qs"
        val text = http.downloadText(url)
        val json = JsonParser.parse(text).asObject()
        val arr = (json as? JsonArray) ?: run {
            // 实际返回是数组
            return parseVersionList(text)
        }
        return emptyList()
    }

    private fun parseVersionList(text: String): List<ModVersion> {
        val arr = JsonParser.parse(text)
        if (arr !is JsonArray) return emptyList()
        return arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map { obj ->
                val files = obj.optArray("files")?.iterator()?.asSequence()
                    ?.filterIsInstance<JsonObject>()
                    ?.toList() ?: emptyList()
                val primary = files.firstOrNull { it.optBoolean("primary") } ?: files.firstOrNull()
                ModVersion(
                    id = obj.optString("id"),
                    projectId = obj.optString("project_id"),
                    versionNumber = obj.optString("version_number"),
                    name = obj.optString("name"),
                    loaders = obj.optArray("loaders")?.asStringList() ?: emptyList(),
                    gameVersions = obj.optArray("game_versions")?.asStringList() ?: emptyList(),
                    downloadUrl = primary?.optString("url") ?: "",
                    filename = primary?.optString("filename") ?: "",
                    sha1 = primary?.optString("hashes", "").let { h ->
                        // hashes 是对象 {"sha1": "...", "sha512": "..."}
                        val ho = (primary?.optObject("hashes"))?.optString("sha1") ?: ""
                        ho
                    },
                    dependencies = obj.optArray("dependencies")?.iterator()?.asSequence()
                        ?.filterIsInstance<JsonObject>()
                        ?.map { dep ->
                            ModDependency(
                                projectId = dep.optString("project_id"),
                                versionId = dep.optString("version_id"),
                                dependencyType = dep.optString("dependency_type") // required / optional / incompatible / embedded
                            )
                        }?.toList() ?: emptyList()
                )
            }.toList()
    }

    private fun parseSearchResult(text: String): SearchResult {
        val json = JsonParser.parse(text).asObject()
        val hits = json.optArray("hits") ?: JsonArray()
        val list = hits.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map { obj ->
                SearchHit(
                    id = obj.optString("project_id"),  // modrinth v2 用 project_id
                    slug = obj.optString("slug"),
                    title = obj.optString("title"),
                    description = obj.optString("description"),
                    author = obj.optString("author"),
                    iconUrl = obj.optString("icon_url"),
                    categories = obj.optArray("categories")?.asStringList() ?: emptyList(),
                    displayCategories = obj.optArray("display_categories")?.asStringList() ?: emptyList(),
                    versions = obj.optArray("versions")?.asStringList() ?: emptyList(),
                    downloads = obj.optLong("downloads"),
                    follows = obj.optLong("follows")
                )
            }.toList()
        return SearchResult(
            total = json.optLong("total", list.size.toLong()).toInt(),
            hits = list
        )
    }

    private fun encode(s: String): String =
        java.net.URLEncoder.encode(s, Charsets.UTF_8.name())

    companion object {
        const val BASE_URL = "https://api.modrinth.com/v2"
    }
}

data class SearchResult(
    val total: Int,
    val hits: List<SearchHit>
)

data class SearchHit(
    val id: String,
    val slug: String,
    val title: String,
    val description: String,
    val author: String,
    val iconUrl: String,
    val categories: List<String>,
    val displayCategories: List<String>,
    val versions: List<String>,
    val downloads: Long,
    val follows: Long
)

data class ModVersion(
    val id: String,
    val projectId: String,
    val versionNumber: String,
    val name: String,
    val loaders: List<String>,
    val gameVersions: List<String>,
    val downloadUrl: String,
    val filename: String,
    val sha1: String,
    val dependencies: List<ModDependency>
)

data class ModDependency(
    val projectId: String,
    val versionId: String?,
    val dependencyType: String
)
