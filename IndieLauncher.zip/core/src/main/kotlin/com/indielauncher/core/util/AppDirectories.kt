package com.indielauncher.core.util

import java.io.File

/**
 * 应用目录布局定义。分三层：
 *   1. 不可变运行工件（JRE / natives / renderers）
 *   2. 可变游戏内容（版本、实例、Mod、资源包、光影）
 *   3. 应用私有数据（账号、配置、缓存）
 *
 * 对应调研报告中"不可变运行工件 / 可变用户内容 / 应用私有数据"三层划分。
 */
class AppDirectories private constructor(
    private val root: File
) {

    constructor(base: File) : this(File(base, "indielauncher"))

    val rootDir: File get() = root

    /** 游戏版本库：games/<version-id>/ */
    val gamesDir: File = File(root, "games")

    /** 共享依赖库：libraries/ */
    val librariesDir: File = File(root, "libraries")

    /** 游戏资源索引：assets/ */
    val assetsDir: File = File(root, "assets")

    /** 各版本 natives：natives/<version>/<abi>/ */
    val nativesDir: File = File(root, "natives")

    /** JRE 运行时：runtime/jre-<version>-<abi>/ */
    val runtimeDir: File = File(root, "runtime")

    /** 原生运行时组件：natives-components/<component>/<abi>/ */
    val runtimeComponentsDir: File = File(root, "natives-components")

    /** 渲染后端：renderers/<backend>/<abi>/ */
    val renderersDir: File = File(root, "renderers")

    /** 实例配置：profiles/ */
    val profilesDir: File = File(root, "profiles")

    /** 日志：logs/ */
    val logsDir: File = File(root, "logs")

    /** 临时下载目录：tmp/ */
    val tempDir: File = File(root, "tmp")

    /** 整合包缓存：pack-cache/ */
    val packCacheDir: File = File(root, "pack-cache")

    fun ensureDirectories() {
        listOf(
            root, gamesDir, librariesDir, assetsDir, nativesDir,
            runtimeDir, runtimeComponentsDir, renderersDir,
            profilesDir, logsDir, tempDir, packCacheDir
        ).forEach { it.mkdirs() }
    }

    /** 某实例的游戏目录。每个 profile 一个隔离目录，避免 mods/ 互相污染。 */
    fun instanceDir(profileId: String): File = File(gamesDir, profileId)

    fun instanceModsDir(profileId: String): File = File(instanceDir(profileId), "mods")
    fun instanceResourcePacksDir(profileId: String): File = File(instanceDir(profileId), "resourcepacks")
    fun instanceShaderPacksDir(profileId: String): File = File(instanceDir(profileId), "shaderpacks")
    fun instanceConfigDir(profileId: String): File = File(instanceDir(profileId), "config")
    fun instanceNativesDir(profileId: String, abi: String): File =
        File(nativesDir, "$profileId/$abi")
}
