package com.indielauncher.core.auth

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import kotlinx.coroutines.delay

/**
 * 微软账号 OAuth2 设备代码流认证。
 *
 * 完整链路：Device Code -> MSA Token -> XBL Token -> XSTS Token
 *          -> Minecraft Auth -> Minecraft Profile
 *
 * 必须在 https://portal.azure.com/ 注册应用，账户类型选
 * "多租户 + 个人微软账户"，并在"身份验证"里启用公共客户端流。
 *
 * 设计参考 FCL / Pojav 的认证流程思路，全部自研实现。
 */
class MicrosoftAuth(
    private val clientId: String,
    private val http: HttpClient = HttpClient()
) {

    /** 第一步：获取设备代码，返回用户需要在浏览器访问的 URL 与设备码。 */
    suspend fun requestDeviceCode(): DeviceCodeResponse {
        val form = mapOf(
            "client_id" to clientId,
            "scope" to "Xboxlive.signin offline_access"
        )
        val resp = postForm(MS_DEVICECODE_URL, form)
        val json = JsonParser.parse(resp).asObject()
        return DeviceCodeResponse(
            userCode = json.optString("user_code"),
            deviceCode = json.optString("device_code"),
            verificationUri = json.optString("verification_uri", "https://www.microsoft.com/link"),
            expiresIn = json.optLong("expires_in", 900L),
            interval = json.optLong("interval", 5L),
            message = json.optString("message")
        )
    }

    /** 第二步：轮询直到用户完成授权。 */
    suspend fun pollForToken(deviceCode: String, intervalSec: Long): MsaTokenResponse {
        val form = mapOf(
            "grant_type" to "urn:ietf:params:oauth:grant-type:device_code",
            "client_id" to clientId,
            "device_code" to deviceCode
        )
        while (true) {
            delay(intervalSec * 1000)
            try {
                val resp = postForm(MS_TOKEN_URL, form)
                val json = JsonParser.parse(resp).asObject()
                return MsaTokenResponse(
                    accessToken = json.optString("access_token"),
                    refreshToken = json.optString("refresh_token"),
                    expiresIn = json.optLong("expires_in", 3600L)
                )
            } catch (e: AuthorizationPendingException) {
                // 继续轮询
            }
        }
    }

    /** 第三步：用 MSA token 换取 Xbox Live token。 */
    suspend fun exchangeXbl(msaToken: String): XblResponse {
        val body = """{"Properties":{"AuthMethod":"RPS","SiteName":"user.auth.xboxlive.com","RpsTicket":"d=$msaToken"},"RelyingParty":"http://auth.xboxlive.com","TokenType":"JWT"}"""
        val resp = postJson(XBL_AUTH_URL, body)
        val json = JsonParser.parse(resp).asObject()
        return XblResponse(token = json.optString("Token"))
    }

    /** 第四步：用 XBL token 换取 XSTS token。 */
    suspend fun exchangeXsts(xblToken: String): XstsResponse {
        val body = """{"Properties":{"SandboxId":"RETAIL","UserTokens":["$xblToken"]},"RelyingParty":"http://xboxlive.com","TokenType":"JWT"}"""
        val resp = postJson(XSTS_AUTH_URL, body)
        val json = JsonParser.parse(resp).asObject()
        val arr = json.optArray("DisplayClaims") ?: error("XSTS 响应缺少 DisplayClaims")
        val obj = arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .firstOrNull { it.optString("uhs").isNotEmpty() }
            ?: error("XSTS 响应缺少 uhs")
        return XstsResponse(token = json.optString("Token"), uhs = obj.optString("uhs"))
    }

    /** 第五步：用 XSTS token 换取 Minecraft access token。 */
    suspend fun loginMinecraft(xstsToken: String, uhs: String): String {
        val body = """{"identityToken":"XBL3.0 x=$uhs;$xstsToken"}"""
        val resp = postJson(MC_AUTH_URL, body, header = "Bearer $xstsToken")
        val json = JsonParser.parse(resp).asObject()
        return json.optString("access_token")
    }

    /** 第六步：获取 Minecraft 角色（玩家 UUID + 用户名）。 */
    suspend fun fetchProfile(mcToken: String): McProfile {
        val req = java.net.http.HttpRequest.newBuilder()
            .uri(java.net.URI.create(MC_PROFILE_URL))
            .header("Authorization", "Bearer $mcToken")
            .GET()
            .build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        if (resp.statusCode() !in 200..299) {
            throw IllegalStateException("获取角色失败: HTTP ${resp.statusCode()}")
        }
        val json = JsonParser.parse(resp.body()!!).asObject()
        val uuid = UUID.fromString(dashedUuid(json.optString("id")))
        return McProfile(uuid = uuid, username = json.optString("name"))
    }

    /** 刷新 access token。 */
    suspend fun refresh(refreshToken: String): MsaTokenResponse {
        val form = mapOf(
            "grant_type" to "refresh_token",
            "client_id" to clientId,
            "refresh_token" to refreshToken
        )
        val resp = postForm(MS_TOKEN_URL, form)
        val json = JsonParser.parse(resp).asObject()
        return MsaTokenResponse(
            accessToken = json.optString("access_token"),
            refreshToken = json.optString("refresh_token", refreshToken),
            expiresIn = json.optLong("expires_in", 3600L)
        )
    }

    private suspend fun postForm(url: String, form: Map<String, String>): String {
        val body = form.entries.joinToString("&") { (k, v) ->
            "${urlEncode(k)}=${urlEncode(v)}"
        }
        val req = java.net.http.HttpRequest.newBuilder()
            .uri(java.net.URI.create(url))
            .header("Content-Type", "application/x-www-form-urlencoded")
            .POST(java.net.http.HttpRequest.BodyPublishers.ofString(body))
            .build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        val text = resp.body() ?: ""
        if (resp.statusCode() == 400) {
            val err = runCatching { JsonParser.parse(text).asObject() }.getOrNull()
            val errCode = err?.optString("error")
            if (errCode == "authorization_pending") throw AuthorizationPendingException()
        }
        if (resp.statusCode() !in 200..299) {
            throw IllegalStateException("HTTP ${resp.statusCode()}: $text")
        }
        return text
    }

    private suspend fun postJson(url: String, body: String, header: String? = null): String {
        val builder = java.net.http.HttpRequest.newBuilder()
            .uri(java.net.URI.create(url))
            .header("Content-Type", "application/json")
        header?.let { builder.header("Authorization", it) }
        val req = builder.POST(java.net.http.HttpRequest.BodyPublishers.ofString(body)).build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        if (resp.statusCode() !in 200..299) {
            throw IllegalStateException("HTTP ${resp.statusCode()}: ${resp.body()}")
        }
        return resp.body() ?: ""
    }

    private fun urlEncode(s: String): String =
        java.net.URLEncoder.encode(s, Charsets.UTF_8.name())

    private fun dashedUuid(plain: String): String {
        if (plain.length != 32) return plain
        return buildString {
            append(plain.substring(0, 8))
            append('-').append(plain.substring(8, 12))
            append('-').append(plain.substring(12, 16))
            append('-').append(plain.substring(16, 20))
            append('-').append(plain.substring(20, 32))
        }
    }

    companion object {
        private const val MS_DEVICECODE_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
        private const val MS_TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
        private const val XBL_AUTH_URL = "https://user.auth.xboxlive.com/user/authenticate"
        private const val XSTS_AUTH_URL = "https://xsts.auth.xboxlive.com/xsts/authorize"
        private const val MC_AUTH_URL = "https://api.minecraftservices.com/authentication/login_with_xbox"
        private const val MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"
    }
}

class AuthorizationPendingException : Exception("authorization_pending")

data class DeviceCodeResponse(
    val userCode: String,
    val deviceCode: String,
    val verificationUri: String,
    val expiresIn: Long,
    val interval: Long,
    val message: String
)

data class MsaTokenResponse(
    val accessToken: String,
    val refreshToken: String,
    val expiresIn: Long
)

data class XblResponse(val token: String)
data class XstsResponse(val token: String, val uhs: String)
data class McProfile(val uuid: java.util.UUID, val username: String)
