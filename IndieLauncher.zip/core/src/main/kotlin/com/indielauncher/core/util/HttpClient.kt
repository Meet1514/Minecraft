package com.indielauncher.core.util

import java.io.File
import java.io.RandomAccessFile
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.time.Duration
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * 纯 JDK 实现的 HTTP 客户端，支持断点续传与 SHA 校验。
 *
 * 设计参考 FCL / Pojav 的下载器思路（索引—队列—校验—原子落盘），
 * 但全部自研实现，不复制任何第三方代码。
 */
class HttpClient(
    private val connectTimeoutMs: Long = 10_000,
    private val readTimeoutMs: Long = 30_000,
    private val userAgent: String = "IndieLauncher/0.1.0"
) {

    private val client: java.net.http.HttpClient = java.net.http.HttpClient.newBuilder()
        .connectTimeout(Duration.ofMillis(connectTimeoutMs))
        .executor(executor)
        .build()

    /** 下载并校验。失败抛异常。支持断点续传（Range 请求）。 */
    fun download(
        url: String,
        dest: File,
        expectedSha1: String? = null,
        expectedSha256: String? = null,
        algorithm: String = "sha-1",
        progress: (Long, Long) -> Unit = { _, _ -> }
    ) {
        dest.parentFile?.mkdirs()
        val partFile = File(dest.parentFile, dest.name + ".part")

        // 已存在且校验通过则跳过
        if (dest.exists() && dest.length() > 0) {
            val ok = when (algorithm.lowercase()) {
                "sha-256", "sha256" -> Hash.verify(dest, "sha-256", expectedSha256)
                else -> Hash.verify(dest, "sha-1", expectedSha1)
            }
            if (ok) {
                progress(dest.length(), dest.length())
                return
            }
        }

        // 断点续传：读取已下载字节数
        val existing = if (partFile.exists()) partFile.length() else 0L
        val requestBuilder = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .timeout(Duration.ofMillis(readTimeoutMs))
            .header("User-Agent", userAgent)
            .header("Accept", "*/*")
        if (existing > 0) {
            requestBuilder.header("Range", "bytes=$existing-")
        }
        val request = requestBuilder.GET().build()

        val response = client.send(request, HttpResponse.BodyHandlers.ofInputStream())
        val status = response.statusCode()
        val total = response.headers().firstValueAsLong("Content-Length").orElse(-1L)
        val rangeStart = response.headers().firstValue("Content-Range").orElse(null)

        val output = RandomAccessFile(partFile, "rw")
        try {
            if (status == 206 && rangeStart != null) {
                // 续传，保持当前位置
            } else if (existing > 0 && status == 200) {
                // 服务器不支持 Range，重头开始
                output.setLength(0)
            }
            output.seek(output.length())

            response.body().use { input ->
                val buffer = ByteArray(8192)
                var read: Int
                while (input.read(buffer).also { read = it } != -1) {
                    output.write(buffer, 0, read)
                    progress(output.length(), total)
                }
            }
        } finally {
            output.close()
        }

        // 校验
        val algo = when (algorithm.lowercase()) {
            "sha-256", "sha256" -> "sha-256" to expectedSha256
            else -> "sha-1" to expectedSha1
        }
        if (!algo.second.isNullOrBlank() && !Hash.verify(partFile, algo.first, algo.second)) {
            partFile.delete()
            throw IllegalStateException("SHA 校验失败: $url")
        }

        // 原子重命名
        if (dest.exists()) dest.delete()
        if (!partFile.renameTo(dest)) {
            partFile.copyTo(dest, overwrite = true)
            partFile.delete()
        }
    }

    /** 下载文本（版本清单、version.json 等）。 */
    fun downloadText(url: String): String {
        val request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .timeout(Duration.ofMillis(readTimeoutMs))
            .header("User-Agent", userAgent)
            .GET()
            .build()
        val response = client.send(request, HttpResponse.BodyHandlers.ofString())
        if (response.statusCode() !in 200..299) {
            throw IllegalStateException("HTTP ${response.statusCode()} for $url")
        }
        return response.body()
    }

    /** 下载字节数组。 */
    fun downloadBytes(url: String): ByteArray {
        val request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .timeout(Duration.ofMillis(readTimeoutMs))
            .header("User-Agent", userAgent)
            .GET()
            .build()
        val response = client.send(request, HttpResponse.BodyHandlers.ofByteArray())
        if (response.statusCode() !in 200..299) {
            throw IllegalStateException("HTTP ${response.statusCode()} for $url")
        }
        return response.body()
    }

    companion object {
        private val executor: ExecutorService = Executors.newFixedThreadPool(4)
    }
}
