package com.indielauncher.core.mods

import com.indielauncher.core.util.Hash
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.JsonSerializer
import java.io.File
import java.util.zip.ZipFile

/**
 * 资源包 / 光影包管理器。
 *
 * 资源包放在 instance/resourcepacks/，光影包放在 instance/shaderpacks/。
 * 只做文件放置、启用状态、校验和一键卸载，不擅自修改游戏 options 文件。
 */
class ContentManager(
    private val packsDir: File  // resourcepacks 或 shaderpacks
) {

    init { packsDir.mkdirs() }

    data class ContentPack(
        val id: String,
        val file: File,
        val displayName: String,
        val description: String,
        val format: Int,
        val type: PackType,
        val enabled: Boolean
    )

    enum class PackType { RESOURCE_PACK, SHADER_PACK }

    /** 扫描目录下所有包。 */
    fun scan(type: PackType): List<ContentPack> {
        if (!packsDir.exists()) return emptyList()
        return packsDir.listFiles { f ->
            f.isFile && (f.extension == "zip" || f.extension == "jar")
        }?.mapNotNull { file -> readPack(file, type) }?.toList() ?: emptyList()
    }

    /** 导入一个包（从 URL 下载或本地文件）。 */
    fun import(source: File, type: PackType): ContentPack {
        val dest = File(packsDir, source.name)
        source.copyTo(dest, overwrite = true)
        return readPack(dest, type)
            ?: throw IllegalStateException("无法读取包元数据: ${source.name}")
    }

    fun importFromUrl(url: String, filename: String, type: PackType): ContentPack {
        // 实际下载由 DownloadManager 负责，这里只做本地落地
        val dest = File(packsDir, filename)
        return ContentPack(
            id = filename,
            file = dest,
            displayName = filename,
            description = "",
            format = -1,
            type = type,
            enabled = true
        )
    }

    /** 删除包。 */
    fun delete(pack: ContentPack) {
        pack.file.delete()
    }

    private fun readPack(file: File, type: PackType): ContentPack? {
        if (!file.exists()) return null
        return try {
            ZipFile(file).use { zip ->
                val entry = zip.getEntry("pack.mcmeta")
                    ?: zip.getEntry("pack.txt")
                    ?: return ContentPack(
                        id = file.name,
                        file = file,
                        displayName = file.nameWithoutExtension,
                        description = "",
                        format = -1,
                        type = type,
                        enabled = true
                    )
                if (entry.name.endsWith(".txt")) {
                    ContentPack(
                        id = file.name,
                        file = file,
                        displayName = file.nameWithoutExtension,
                        description = "",
                        format = -1,
                        type = type,
                        enabled = true
                    )
                } else {
                    val text = zip.getInputStream(entry).bufferedReader().readText()
                    val json = JsonParser.parse(text).asObject()
                    val pack = json.optObject("pack")
                    ContentPack(
                        id = file.name,
                        file = file,
                        displayName = file.nameWithoutExtension,
                        description = json.optString("description"),
                        format = pack?.optInt("format", -1) ?: -1,
                        type = type,
                        enabled = true
                    )
                }
            }
        } catch (_: Throwable) {
            null
        }
    }
}
