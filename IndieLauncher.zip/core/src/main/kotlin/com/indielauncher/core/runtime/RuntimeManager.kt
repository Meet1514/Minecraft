package com.indielauncher.core.runtime

import com.indielauncher.core.download.DownloadManager
import com.indielauncher.core.download.DownloadTask
import com.indielauncher.core.util.Hash
import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import java.io.File
import java.util.zip.ZipFile

/**
 * JRE 运行时管理器。
 *
 * 嵌入式 JRE 必须是为 Android 交叉编译的版本（参考 PojavLauncher 的 JRE 构建）。
 * 运行时清单从自有服务器拉取（或本地 assets 中的 runtime-manifests/*.json）。
 *
 * 清单格式（运行时清单）：
 * {
 *   "id": "jre-17-android-aarch64",
 *   "javaVersion": 17,
 *   "abi": "arm64-v8a",
 *   "uri": "https://your-mirror/runtime/jre-17-aarch64.zip",
 *   "sha256": "...",
 *   "size": 47185920,
 *   "minAndroidSdk": 24,
 *   "sourceCommit": "...",
 *   "sourceUrl": "https://github.com/.../archive/....tar.gz"
 * }
 *
 * 安装策略：下载到 incoming/ -> 校验 -> 解压到 stage/ -> rename 到 runtimes/<id>/
 * 保证原子切换，避免崩溃恢复时加载半写坏的 libjvm.so。
 */
class RuntimeManager(
    private val runtimeDir: File,
    private val downloader: DownloadManager,
    private val http: HttpClient = HttpClient()
) {

    data class RuntimeManifest(
        val id: String,
        val javaVersion: Int,
        val abi: String,
        val uri: String,
        val sha256: String,
        val size: Long,
        val minAndroidSdk: Int = 24,
        val sourceCommit: String = "",
        val sourceUrl: String = ""
    ) {
        fun localDir(base: File): File = File(base, id)
        fun componentJson(base: File): File = File(localDir(base), "component.json")
    }

    private var manifestCache: List<RuntimeManifest> = emptyList()

    /** 从 URL 或本地文件加载运行时清单。 */
    fun fetchManifests(url: String? = null): List<RuntimeManifest> {
        return if (url != null) {
            val text = http.downloadText(url)
            parseManifests(text)
        } else {
            // 从 assets 目录加载（打包在 APK 中）
            parseManifests("{\"runtimes\":[]}")
        }
    }

    private fun parseManifests(text: String): List<RuntimeManifest> {
        val json = JsonParser.parse(text).asObject()
        val arr = json.optArray("runtimes") ?: return emptyList()
        return arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map {
                RuntimeManifest(
                    id = it.optString("id"),
                    javaVersion = it.optInt("javaVersion"),
                    abi = it.optString("abi"),
                    uri = it.optString("uri"),
                    sha256 = it.optString("sha256"),
                    size = it.optLong("size"),
                    minAndroidSdk = it.optInt("minAndroidSdk", 24),
                    sourceCommit = it.optString("sourceCommit"),
                    sourceUrl = it.optString("sourceUrl")
                )
            }.toList()
    }

    /** 选择匹配当前 ABI 与 Java 版本要求的最佳运行时。 */
    fun selectRuntime(manifests: List<RuntimeManifest>, abi: String, minJavaVersion: Int): RuntimeManifest? {
        return manifests
            .filter { it.abi == abi && it.javaVersion >= minJavaVersion }
            .minByOrNull { it.javaVersion }
    }

    /** 安装运行时（异步，通过 downloader）。 */
    fun install(manifest: RuntimeManifest): File {
        runtimeDir.mkdirs()
        val incoming = File(runtimeDir, "incoming/${manifest.id}.zip")
        val stage = File(runtimeDir, "stage/${manifest.id}")
        val finalDir = manifest.localDir(runtimeDir)

        val task = DownloadTask(
            url = manifest.uri,
            dest = incoming,
            expectedSha256 = manifest.sha256,
            algorithm = "sha-256",
            size = manifest.size,
            tag = "runtime"
        )
        downloader.submit(task)

        // 等待下载完成
        while (!downloader.isAllCompleted()) Thread.sleep(100)
        if (downloader.hasFailures()) {
            throw IllegalStateException("运行时下载失败: ${manifest.id}")
        }

        // 解压到 stage
        stage.mkdirs()
        extractZip(incoming, stage)

        // 写 component.json
        val component = linkedMapOf(
            "name" to manifest.id,
            "version" to manifest.javaVersion,
            "commit" to manifest.sourceCommit,
            "license" to "GPLv2+Classpath",
            "sourceUrl" to manifest.sourceUrl
        )
        manifest.componentJson(runtimeDir).writeText(
            com.indielauncher.core.util.JsonSerializer.serialize(component)
        )

        // 原子 rename
        if (finalDir.exists()) finalDir.deleteRecursively()
        stage.renameTo(finalDir)
        incoming.delete()

        return finalDir
    }

    /** 检查运行时是否已安装且完整。 */
    fun isInstalled(manifest: RuntimeManifest): Boolean {
        val dir = manifest.localDir(runtimeDir)
        if (!dir.exists()) return false
        // 检查关键文件
        return File(dir, "bin/java").exists() ||
            File(dir, "lib/libjvm.so").exists() ||
            File(dir, "lib/server/libjvm.so").exists() ||
            File(dir, "lib/jli/libjli.so").exists()
    }

    /** 列出已安装的运行时。 */
    fun listInstalled(): List<File> {
        if (!runtimeDir.exists()) return emptyList()
        return runtimeDir.listFiles { f -> f.isDirectory && f.name != "incoming" && f.name != "stage" }
            ?.filter { isInstalledByHeuristic(it) }
            ?.toList() ?: emptyList()
    }

    private fun isInstalledByHeuristic(dir: File): Boolean {
        return File(dir, "bin/java").exists() ||
            File(dir, "lib/libjvm.so").exists() ||
            File(dir, "lib/server/libjvm.so").exists()
    }

    /** 卸载运行时。 */
    fun uninstall(manifest: RuntimeManifest) {
        manifest.localDir(runtimeDir).deleteRecursively()
    }

    private fun extractZip(zip: File, dest: File) {
        ZipFile(zip).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val entry = entries.nextElement()
                val outFile = File(dest, entry.name)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                    continue
                }
                outFile.parentFile?.mkdirs()
                zf.getInputStream(entry).use { input ->
                    outFile.outputStream().use { input.copyTo(it) }
                }
            }
        }
        // 设置可执行权限
        File(dest, "bin").listFiles()?.forEach { it.setExecutable(true) }
    }
}
