package com.indielauncher.core.auth

import java.util.UUID

/**
 * 账号类型。离线账号 UUID 按 RFC 4122 v3（"OfflinePlayer:" + name 做 MD5）
 * 生成，与 Minecraft 官方离线逻辑一致，保证不同启动器间 UUID 互通。
 */
sealed class Account(
    open val id: String,
    open val username: String,
    open val uuid: UUID,
    open val type: String
) {
    abstract fun isOffline(): Boolean
}

data class OfflineAccount(
    override val id: String,
    override val username: String,
    override val uuid: UUID = generateOfflineUuid(username),
    override val type: String = "offline"
) : Account(id, username, uuid, type) {
    override fun isOffline(): Boolean = true
}

/**
 * 微软正版账号。
 * accessToken 是 Minecraft 服务令牌，用于进入游戏；
 * refreshToken 用于静默刷新（有效期较长，需安全存储）。
 */
data class MicrosoftAccount(
    override val id: String,
    override val username: String,
    override val uuid: UUID,
    val accessToken: String,
    val refreshToken: String,
    val expiresAtMs: Long,
    override val type: String = "microsoft"
) : Account(id, username, uuid, type) {
    override fun isOffline(): Boolean = false

    fun isExpired(): Boolean = System.currentTimeMillis() >= expiresAtMs
}

private fun generateOfflineUuid(name: String): UUID {
    val md = java.security.MessageDigest.getInstance("MD5")
    val digest = md.digest("OfflinePlayer:$name".toByteArray(Charsets.UTF_8))
    digest[6] = ((digest[6].toInt() and 0x0f) or 0x30).toByte()  // version 3
    digest[8] = ((digest[8].toInt() and 0x3f) or 0x80).toByte()  // variant
    var msb = 0L
    var lsb = 0L
    for (i in 0..7) msb = (msb shl 8) or (digest[i].toLong() and 0xff)
    for (i in 8..15) lsb = (lsb shl 8) or (digest[i].toLong() and 0xff)
    return UUID(msb, lsb)
}
