package com.indielauncher.core.auth

import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.JsonSerializer
import java.io.File
import java.util.UUID

/**
 * 账号持久化存储。Android 侧会替换为用 EncryptedSharedPreferences 存储敏感 token。
 *
 * 文件格式：
 * {
 *   "accounts": [
 *     { "type": "offline", "id": "...", "username": "...", "uuid": "..." },
 *     { "type": "microsoft", ... }
 *   ],
 *   "activeId": "..."
 * }
 */
class AccountStore(private val file: File) {

    private val accounts = mutableListOf<Account>()
    private var activeId: String? = null

    init {
        load()
    }

    @Synchronized
    fun load() {
        if (!file.exists()) return
        try {
            val json = JsonParser.parse(file.readText()).asObject()
            val arr = json.optArray("accounts") ?: return
            accounts.clear()
            for (el in arr) {
                if (el !is com.indielauncher.core.util.JsonObject) continue
                when (el.optString("type")) {
                    "offline" -> accounts.add(
                        OfflineAccount(
                            id = el.optString("id"),
                            username = el.optString("username"),
                            uuid = UUID.fromString(el.optString("uuid"))
                        )
                    )
                    "microsoft" -> accounts.add(
                        MicrosoftAccount(
                            id = el.optString("id"),
                            username = el.optString("username"),
                            uuid = UUID.fromString(el.optString("uuid")),
                            accessToken = el.optString("accessToken"),
                            refreshToken = el.optString("refreshToken"),
                            expiresAtMs = el.optLong("expiresAtMs")
                        )
                    )
                }
            }
            activeId = json.optString("activeId").ifBlank { null }
        } catch (t: Throwable) {
            // 损坏的文件不阻塞启动，重新创建
            accounts.clear()
        }
    }

    @Synchronized
    fun save() {
        file.parentFile?.mkdirs()
        val list = accounts.map { acc ->
            when (acc) {
                is OfflineAccount -> mapOf(
                    "type" to "offline",
                    "id" to acc.id,
                    "username" to acc.username,
                    "uuid" to acc.uuid.toString()
                )
                is MicrosoftAccount -> mapOf(
                    "type" to "microsoft",
                    "id" to acc.id,
                    "username" to acc.username,
                    "uuid" to acc.uuid.toString(),
                    "accessToken" to acc.accessToken,
                    "refreshToken" to acc.refreshToken,
                    "expiresAtMs" to acc.expiresAtMs
                )
            }
        }
        val map = linkedMapOf<String, Any?>(
            "accounts" to list,
            "activeId" to (activeId ?: "")
        )
        file.writeText(JsonSerializer.serialize(map))
    }

    fun add(account: Account) {
        accounts.removeIf { it.id == account.id }
        accounts.add(account)
        if (activeId == null) activeId = account.id
        save()
    }

    fun remove(id: String) {
        accounts.removeIf { it.id == id }
        if (activeId == id) activeId = accounts.firstOrNull()?.id
        save()
    }

    fun list(): List<Account> = accounts.toList()

    fun getActive(): Account? = activeId?.let { id -> accounts.find { it.id == id } }

    fun setActive(id: String) {
        activeId = id
        save()
    }

    fun updateMicrosoft(acc: MicrosoftAccount) {
        val idx = accounts.indexOfFirst { it.id == acc.id }
        if (idx >= 0) accounts[idx] = acc else accounts.add(acc)
        save()
    }
}
