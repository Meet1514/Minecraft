package com.indielauncher.core.game

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser

/**
 * 官方版本清单。入口：https://launchermeta.mojang.com/mc/game/version_manifest.json
 *
 * 该清单列出所有可下载的游戏版本及其元数据 URL。
 */
class VersionManifest(
    private val http: HttpClient = HttpClient()
) {

    data class VersionRef(
        val id: String,
        val type: String, // release / snapshot / old_alpha / old_beta
        val url: String,
        val time: String,
        val releaseTime: String,
        val sha1: String
    )

    private var cached: List<VersionRef>? = null

    /** 拉取版本清单，可强制刷新缓存。 */
    fun fetch(force: Boolean = false): List<VersionRef> {
        if (!force && cached != null) return cached!!

        val text = http.downloadText(MANIFEST_URL)
        val json = JsonParser.parse(text).asObject()
        val arr = json.optArray("versions") ?: throw IllegalStateException("清单格式错误：缺少 versions")

        val list = mutableListOf<VersionRef>()
        for (el in arr) {
            if (el !is JsonObject) continue
            list.add(
                VersionRef(
                    id = el.optString("id"),
                    type = el.optString("type", "release"),
                    url = el.optString("url"),
                    time = el.optString("time"),
                    releaseTime = el.optString("releaseTime"),
                    sha1 = el.optString("sha1")
                )
            )
        }
        cached = list
        return list
    }

    fun findVersion(id: String): VersionRef? =
        fetch().firstOrNull { it.id == id }

    /** 拉取最新正式版。 */
    fun latestRelease(): VersionRef? =
        fetch().firstOrNull { it.type == "release" }

    /** 拉取某个版本的完整元数据 JSON（version.json）。 */
    fun fetchVersionJson(ref: VersionRef): VersionMeta {
        val text = http.downloadText(ref.url)
        val json = JsonParser.parse(text).asObject()
        return VersionMeta.parse(json, ref.id)
    }

    companion object {
        const val MANIFEST_URL = "https://launchermeta.mojang.com/mc/game/version_manifest.json"
    }
}
