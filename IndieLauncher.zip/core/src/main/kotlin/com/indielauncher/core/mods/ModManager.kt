package com.indielauncher.core.mods

import com.indielauncher.core.download.DownloadManager
import com.indielauncher.core.download.DownloadTask
import com.indielauncher.core.util.Hash
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.JsonSerializer
import java.io.File
import java.util.UUID

/**
 * Mod 管理器。负责扫描、安装、启用/禁用、卸载 Mod。
 *
 * 每个 profile 拥有独立的 mods/ 目录。启动器维护 managed-mods.json
 * 记录来源与哈希，真实 Mod JAR 保持原文件名，避免与 loader 扫描器冲突。
 * 禁用时移到 mods.disabled/，不删除文件。
 */
class ModManager(
    private val modsDir: File,
    private val downloader: DownloadManager
) {

    private val managedFile: File get() = File(modsDir.parentFile, "managed-mods.json")
    private val disabledDir: File get() = File(modsDir, ".disabled")

    private val managed = mutableListOf<Mod>()

    init {
        modsDir.mkdirs()
        disabledDir.mkdirs()
        load()
    }

    /** 扫描 mods 目录，识别所有 Mod。 */
    fun scan(): List<Mod> {
        if (!modsDir.exists()) return emptyList()
        return modsDir.listFiles { f -> f.isFile && f.extension == "jar" }
            ?.map { file ->
                val info = ModMetadataReader.read(file)
                // 优先用 managed 中的记录（含来源信息）
                managed.firstOrNull { it.fileName() == file.name }?.copy(file = file)
                    ?: Mod(
                        id = info.id, file = file,
                        displayName = info.displayName, version = info.version,
                        description = info.description, authors = info.authors,
                        loader = info.loader, gameVersions = info.gameVersions,
                        source = ModSource.LOCAL, sourceId = "", fileId = "",
                        downloadUrl = "", sha1 = Hash.sha1(file), enabled = true
                    )
            }?.toList() ?: emptyList()
    }

    /** 安装一个 Mod（从 URL 下载）。 */
    fun install(
        displayName: String,
        version: String,
        loader: ModLoader,
        downloadUrl: String,
        filename: String,
        sha1: String,
        source: ModSource,
        sourceId: String,
        fileId: String,
        gameVersions: List<String>
    ): Mod {
        val dest = File(modsDir, filename)
        val task = DownloadTask(
            url = downloadUrl,
            dest = dest,
            expectedSha1 = sha1,
            tag = "mod"
        )
        downloader.submit(task)

        val mod = Mod(
            id = filename, file = dest,
            displayName = displayName, version = version,
            description = "", authors = emptyList(),
            loader = loader, gameVersions = gameVersions,
            source = source, sourceId = sourceId, fileId = fileId,
            downloadUrl = downloadUrl, sha1 = sha1, enabled = true
        )
        managed.add(mod)
        save()
        return mod
    }

    /** 启用/禁用 Mod。 */
    fun setEnabled(mod: Mod, enabled: Boolean) {
        val target = managed.firstOrNull { it.id == mod.id } ?: return
        if (enabled) {
            // 从 .disabled 移回
            val disabled = File(disabledDir, mod.fileName())
            if (disabled.exists()) {
                disabled.copyTo(target.file, overwrite = true)
                disabled.delete()
            }
        } else {
            // 移到 .disabled
            val disabled = File(disabledDir, mod.fileName())
            if (target.file.exists()) {
                target.file.copyTo(disabled, overwrite = true)
                target.file.delete()
            }
        }
        managed[managed.indexOf(target)] = target.copy(enabled = enabled)
        save()
    }

    /** 卸载 Mod（彻底删除文件）。 */
    fun uninstall(mod: Mod) {
        mod.file.delete()
        File(disabledDir, mod.fileName()).delete()
        managed.removeIf { it.id == mod.id }
        save()
    }

    /** 列出所有已管理的 Mod。 */
    fun list(): List<Mod> = managed.toList()

    private fun load() {
        if (!managedFile.exists()) return
        try {
            val json = JsonParser.parse(managedFile.readText()).asObject()
            val arr = json.optArray("mods") ?: return
            managed.clear()
            for (el in arr) {
                if (el !is JsonObject) continue
                managed.add(
                    Mod(
                        id = el.optString("id"),
                        file = File(modsDir, el.optString("filename")),
                        displayName = el.optString("displayName"),
                        version = el.optString("version"),
                        description = el.optString("description"),
                        authors = el.optArray("authors")?.asStringList() ?: emptyList(),
                        loader = ModLoader.valueOf(el.optString("loader", "UNKNOWN")),
                        gameVersions = el.optArray("gameVersions")?.asStringList() ?: emptyList(),
                        source = ModSource.valueOf(el.optString("source", "LOCAL")),
                        sourceId = el.optString("sourceId"),
                        fileId = el.optString("fileId"),
                        downloadUrl = el.optString("downloadUrl"),
                        sha1 = el.optString("sha1"),
                        enabled = el.optBoolean("enabled", true)
                    )
                )
            }
        } catch (_: Throwable) {
            managed.clear()
        }
    }

    private fun save() {
        managedFile.parentFile?.mkdirs()
        val map = linkedMapOf<String, Any>(
            "schemaVersion" to 1,
            "mods" to managed.map { m ->
                linkedMapOf(
                    "id" to m.id,
                    "filename" to m.fileName(),
                    "displayName" to m.displayName,
                    "version" to m.version,
                    "description" to m.description,
                    "authors" to m.authors,
                    "loader" to m.loader.name,
                    "gameVersions" to m.gameVersions,
                    "source" to m.source.name,
                    "sourceId" to m.sourceId,
                    "fileId" to m.fileId,
                    "downloadUrl" to m.downloadUrl,
                    "sha1" to m.sha1,
                    "enabled" to m.enabled
                )
            }
        )
        managedFile.writeText(JsonSerializer.serialize(map))
    }
}
