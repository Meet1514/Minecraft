package com.indielauncher.core.auth

import java.util.UUID

/**
 * 离线账号工厂。不保存任何密码，只生成符合 Minecraft 规范的离线身份。
 */
object OfflineAccountFactory {

    fun create(username: String): OfflineAccount {
        require(username.isNotBlank()) { "用户名不能为空" }
        require(username.length <= 16) { "用户名不能超过 16 字符" }
        val id = "offline-" + UUID.randomUUID().toString()
        return OfflineAccount(id = id, username = username)
    }
}
