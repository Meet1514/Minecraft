package com.indielauncher.core.util

/**
 * 操作系统与 CPU 架构判定。
 *
 * Minecraft 官方元数据里的 rules 使用 os.name ∈ {linux, windows, osx}，
 * natives classifier 使用 os.arch ∈ {x86, x86_64, arm64, aarch64, arm}，
 * 与 Android ABI 需要映射。
 */
object Os {

    const val NAME_LINUX = "linux"
    const val NAME_WINDOWS = "windows"
    const val NAME_OSX = "osx"

    enum class Arch(val classifier: String) {
        X86("x86"),
        X86_64("x86_64"),
        ARM64("arm64"),
        AARCH64("aarch64"),
        ARM("arm");

        companion object {
            fun fromJvmArch(arch: String): Arch = when (arch.lowercase()) {
                "x86", "i386", "i486", "i586", "i686" -> X86
                "x86_64", "amd64", "x64" -> X86_64
                "arm64", "aarch64" -> ARM64
                "arm", "armeabi", "armeabi-v7a", "aarch32" -> ARM
                else -> X86_64
            }

            /** Android ABI -> Minecraft natives classifier */
            fun fromAndroidAbi(abi: String): Arch = when (abi) {
                "armeabi-v7a" -> ARM
                "arm64-v8a" -> AARCH64
                "x86" -> X86
                "x86_64" -> X86_64
                else -> AARCH64
            }
        }
    }

    fun currentName(): String {
        val os = System.getProperty("os.name", "linux").lowercase()
        return when {
            os.contains("win") -> NAME_WINDOWS
            os.contains("mac") -> NAME_OSX
            else -> NAME_LINUX
        }
    }

    fun currentArch(): Arch = Arch.fromJvmArch(System.getProperty("os.arch", "x86_64"))

    /** 运行在 Android 上（由 Android 层注入） */
    var isAndroid: Boolean = false

    /** Android ABI，由 App 层在启动时设置 */
    var androidAbi: String = "arm64-v8a"

    /** 获取当前上下文的 natives 分类 arch */
    fun nativeArch(): String = if (isAndroid) {
        Arch.fromAndroidAbi(androidAbi).classifier
    } else {
        currentArch().classifier
    }
}
