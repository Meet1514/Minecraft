package com.indielauncher.core.pack

import com.indielauncher.core.download.DownloadManager
import com.indielauncher.core.download.DownloadTask
import com.indielauncher.core.util.Hash
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import java.io.File
import java.util.zip.ZipFile

/**
 * 整合包导入器。
 *
 * 支持格式：
 *   - Modrinth .mrpack（index.json + overrides/）
 *   - CurseForge .zip（manifest.json + overrides/）
 *   - MultiMC 实例包（mmc-pack.json + instance.cfg + .minecraft/）
 *   - 通用 zip（根目录含 .minecraft/）
 *
 * 每个整合包创建独立 game directory 与 profile，避免 mods/ 互相污染。
 */
class PackImporter(
    private val gamesDir: File,
    private val downloader: DownloadManager,
    private val http: com.indielauncher.core.util.HttpClient
) {

    sealed class PackFormat {
        object Mrpack : PackFormat()
        object CurseForge : PackFormat()
        object MultiMC : PackFormat()
        object Generic : PackFormat()
    }

    data class ImportResult(
        val profileId: String,
        val gameDir: File,
        val mcVersion: String,
        val loader: String?,      // fabric / forge / quilt / null
        val loaderVersion: String?,
        val modsCount: Int,
        val packName: String
    )

    /** 从本地 zip 文件导入。 */
    fun importFromZip(zipFile: File, targetProfileId: String? = null): ImportResult {
        val format = detectFormat(zipFile)
        return when (format) {
            is PackFormat.Mrpack -> importMrpack(zipFile, targetProfileId)
            is PackFormat.CurseForge -> importCurseForge(zipFile, targetProfileId)
            is PackFormat.MultiMC -> importMultiMc(zipFile, targetProfileId)
            is PackFormat.Generic -> importGeneric(zipFile, targetProfileId)
        }
    }

    private fun detectFormat(zipFile: File): PackFormat {
        ZipFile(zipFile).use { zip ->
            val names = zip.entries().toList().map { it.name }
            return when {
                zip.getEntry("modrinth.index.json") != null -> PackFormat.Mrpack
                zip.getEntry("manifest.json") != null -> PackFormat.CurseForge
                zip.getEntry("mmc-pack.json") != null -> PackFormat.MultiMC
                names.any { it.startsWith(".minecraft/") } -> PackFormat.Generic
                else -> PackFormat.Generic
            }
        }
    }

    /** Modrinth .mrpack 导入。 */
    private fun importMrpack(zipFile: File, targetProfileId: String?): ImportResult {
        val profileId = targetProfileId ?: zipFile.nameWithoutExtension
        val gameDir = File(gamesDir, profileId)
        gameDir.mkdirs()

        val index = readZipEntry(zipFile, "modrinth.index.json")
            ?: throw IllegalStateException("无效的 mrpack：缺少 modrinth.index.json")

        val json = JsonParser.parse(index).asObject()
        val gameVersion = json.optString("gameVersion")
        val versionId = json.optString("versionId")
        val name = json.optString("name", profileId)

        // 读取 files 列表
        val files = json.optArray("files") ?: throw IllegalStateException("mrpack 缺少 files")
        var modsCount = 0

        for (el in files) {
            if (el !is JsonObject) continue
            val path = el.optString("path")
            val hashes = el.optObject("hashes")
            val sha1 = hashes?.optString("sha1") ?: ""
            val env = el.optObject("env")
            // client 端才需要下载
            val clientSide = env?.optString("client", "required") ?: "required"
            if (clientSide == "unsupported") continue

            val url = el.optString("url")
            if (url.isBlank()) continue

            val dest = File(gameDir, path)
            downloader.submit(
                DownloadTask(
                    url = url, dest = dest, expectedSha1 = sha1, tag = "pack-file"
                )
            )
            modsCount++
        }

        // 解压 overrides 到 gameDir
        extractOverrides(zipFile, gameDir, "overrides/")

        return ImportResult(
            profileId = profileId,
            gameDir = gameDir,
            mcVersion = gameVersion,
            loader = detectLoaderFromDir(gameDir),
            loaderVersion = null,
            modsCount = modsCount,
            packName = name
        )
    }

    /** CurseForge .zip 导入。 */
    private fun importCurseForge(zipFile: File, targetProfileId: String?): ImportResult {
        val profileId = targetProfileId ?: zipFile.nameWithoutExtension
        val gameDir = File(gamesDir, profileId)
        gameDir.mkdirs()

        val manifestText = readZipEntry(zipFile, "manifest.json")
            ?: throw IllegalStateException("无效的 CurseForge 包：缺少 manifest.json")
        val json = JsonParser.parse(manifestText).asObject()
        val mcVersion = json.optObject("minecraft")?.optString("version")
            ?: throw IllegalStateException("manifest 缺少 minecraft.version")
        val loaderObj = json.optObject("minecraft")?.optObject("modLoaders")?.let {
            it.optArray("modLoaders")?.getOrNull(0)
        } ?: json.optObject("minecraft")?.optArray("modLoaders")?.getOrNull(0)
        val loaderId = (loaderObj as? JsonObject)?.optString("id") ?: ""

        // files: [{projectID, fileID, required}]
        val files = json.optArray("files") ?: throw IllegalStateException("manifest 缺少 files")
        var modsCount = 0
        for (el in files) {
            if (el !is JsonObject) continue
            val projectId = el.optLong("projectID").toInt()
            val fileId = el.optLong("fileID").toInt()
            val required = el.optBoolean("required", true)
            if (!required) continue

            // CurseForge 文件 URL 需要 API：https://api.curseforge.com/v1/mods/{modId}/files/{fileId}/download-url
            // 这里只记录，实际下载需 CurseForgeApi 支持
            modsCount++
        }

        // overrides
        extractOverrides(zipFile, gameDir, "overrides/")

        return ImportResult(
            profileId = profileId,
            gameDir = gameDir,
            mcVersion = mcVersion,
            loader = loaderId.substringBefore('-').ifBlank { null },
            loaderVersion = loaderId.substringAfter('-').ifBlank { null },
            modsCount = modsCount,
            packName = json.optString("name", profileId)
        )
    }

    /** MultiMC 实例包导入。 */
    private fun importMultiMc(zipFile: File, targetProfileId: String?): ImportResult {
        val cfgText = readZipEntry(zipFile, "instance.cfg")
            ?: throw IllegalStateException("无效的 MultiMC 包：缺少 instance.cfg")

        val profileId = targetProfileId ?: parseCfg(cfgText, "InstanceName") ?: zipFile.nameWithoutExtension
        val gameDir = File(gamesDir, profileId)
        gameDir.mkdirs()

        val mcVersion = parseCfg(cfgText, "IntendedVersion") ?: ""
        val loader = parseCfg(cfgText, "LoaderType") ?: ""

        // 解压 .minecraft/ 内容到 gameDir
        extractWithPrefix(zipFile, gameDir, ".minecraft/")

        return ImportResult(
            profileId = profileId,
            gameDir = gameDir,
            mcVersion = mcVersion,
            loader = loader.ifBlank { null },
            loaderVersion = null,
            modsCount = 0,
            packName = profileId
        )
    }

    /** 通用 zip 导入（根目录含 .minecraft/）。 */
    private fun importGeneric(zipFile: File, targetProfileId: String?): ImportResult {
        val profileId = targetProfileId ?: zipFile.nameWithoutExtension
        val gameDir = File(gamesDir, profileId)
        extractWithPrefix(zipFile, gameDir, "")
        return ImportResult(
            profileId = profileId,
            gameDir = gameDir,
            mcVersion = "",
            loader = detectLoaderFromDir(gameDir),
            loaderVersion = null,
            modsCount = 0,
            packName = profileId
        )
    }

    private fun extractOverrides(zipFile: File, destDir: File, prefix: String) {
        ZipFile(zipFile).use { zip ->
            for (entry in zip.entries()) {
                if (entry.isDirectory) continue
                if (!entry.name.startsWith(prefix)) continue
                val relative = entry.name.removePrefix(prefix)
                if (relative.isBlank()) continue
                val out = File(destDir, relative)
                out.parentFile?.mkdirs()
                zip.getInputStream(entry).use { input -> out.outputStream().use { input.copyTo(it) } }
            }
        }
    }

    private fun extractWithPrefix(zipFile: File, destDir: File, prefix: String) {
        ZipFile(zipFile).use { zip ->
            for (entry in zip.entries()) {
                if (entry.isDirectory) continue
                if (prefix.isNotEmpty() && !entry.name.startsWith(prefix)) continue
                val relative = if (prefix.isNotEmpty()) entry.name.removePrefix(prefix) else entry.name
                if (relative.isBlank()) continue
                val out = File(destDir, relative)
                out.parentFile?.mkdirs()
                zip.getInputStream(entry).use { input -> out.outputStream().use { input.copyTo(it) } }
            }
        }
    }

    private fun readZipEntry(zipFile: File, entryName: String): String? {
        ZipFile(zipFile).use { zip ->
            val entry = zip.getEntry(entryName) ?: return null
            return zip.getInputStream(entry).bufferedReader().readText()
        }
    }

    private fun parseCfg(text: String, key: String): String? {
        return text.lines()
            .firstOrNull { it.startsWith("$key=") }
            ?.substringAfter("=")
            ?.trim()
            ?.ifBlank { null }
    }

    private fun detectLoaderFromDir(gameDir: File): String? {
        val modsDir = File(gameDir, "mods")
        if (!modsDir.exists()) return null
        val hasFabric = modsDir.listFiles { f -> f.extension == "jar" }?.any { jar ->
            ZipFile(jar).use { z -> z.getEntry("fabric.mod.json") != null }
        } ?: false
        return if (hasFabric) "fabric" else null
    }
}
