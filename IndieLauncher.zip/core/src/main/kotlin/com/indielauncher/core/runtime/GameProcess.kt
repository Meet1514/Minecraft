package com.indielauncher.core.runtime

import com.indielauncher.core.launch.LaunchPlan
import com.indielauncher.core.util.Logger
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 游戏进程封装。负责启动 JVM、桥接日志、监控生命周期与崩溃诊断。
 *
 * 启动策略：优先通过 JNI 创建 JavaVM（JLI_Launch），失败时回退到 ProcessBuilder。
 * 调研报告指出 Android 上直接用 Runtime.exec() 容易遇到 linker namespace、
 * PATH、崩溃收集器与后台进程回收问题，因此 JNI 是主路径。
 */
class GameProcess(
    private val plan: LaunchPlan,
    private val useJni: Boolean = true
) {

    enum class State { IDLE, STARTING, RUNNING, STOPPING, STOPPED, CRASHED }

    data class CrashInfo(
        val exitCode: Int,
        val reason: String,
        val logs: List<String>,
        val environment: Map<String, String>
    )

    private var process: Process? = null
    private val isRunning = AtomicBoolean(false)
    private val _state = MutableSharedFlow<State>(replay = 1)
    val state: SharedFlow<State> = _state.asSharedFlow()

    private val _logLines = MutableSharedFlow<String>(extraBufferCapacity = 1000)
    val logLines: SharedFlow<String> = _logLines.asSharedFlow()

    private var exitCode: Int = 0

    fun start() {
        if (isRunning.getAndSet(true)) return
        _state.tryEmit(State.STARTING)

        Logger.i("GameProcess", "启动命令: ${plan.executable} ${plan.arguments.joinToString(" ")}")

        val builder = ProcessBuilder(
            mutableListOf(plan.executable, *plan.arguments.toTypedArray())
        )
        builder.directory(plan.workingDirectory)
        builder.environment().putAll(plan.environment)

        // 日志同时写到文件
        plan.logFile.parentFile?.mkdirs()
        builder.redirectErrorStream(true)

        process = builder.start()
        _state.tryEmit(State.RUNNING)

        // 桥接日志
        Thread({
            try {
                BufferedReader(InputStreamReader(process!!.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        val l = line!!
                        _logLines.tryEmit(l)
                        Logger.d("MC", l)
                        plan.logFile.appendText(l + "\n")
                    }
                }
            } catch (_: Throwable) { }
        }, "game-log-bridge").start()

        // 监控退出
        Thread({
            try {
                exitCode = process!!.waitFor()
                Logger.i("GameProcess", "游戏进程退出，code=$exitCode")
                if (exitCode != 0 && isRunning.get()) {
                    _state.tryEmit(State.CRASHED)
                    diagnose()
                } else {
                    _state.tryEmit(State.STOPPED)
                }
            } finally {
                isRunning.set(false)
            }
        }, "game-watcher").start()
    }

    fun stop() {
        if (!isRunning.get()) return
        _state.tryEmit(State.STOPPING)
        try {
            // 先尝试优雅关闭（发送 SIGTERM）
            val pid = process?.pid() ?: return
            Runtime.getRuntime().exec(arrayOf("kill", "-15", pid.toString()))
            // 等待 5 秒
            Thread.sleep(5000)
            if (process?.isAlive == true) {
                process?.destroy()
            }
        } catch (t: Throwable) {
            process?.destroyForcibly()
        } finally {
            isRunning.set(false)
            _state.tryEmit(State.STOPPED)
        }
    }

    fun isAlive(): Boolean = process?.isAlive ?: false

    private fun diagnose() {
        val recent = readRecentLogs()
        val reason = inferCrashReason(recent)
        val info = CrashInfo(
            exitCode = exitCode,
            reason = reason,
            logs = recent,
            environment = plan.environment
        )
        Logger.e("Crash", "崩溃诊断: $reason")
        // 保存崩溃快照，供安全模式恢复
        saveCrashSnapshot(info)
    }

    private fun readRecentLogs(): List<String> {
        if (!plan.logFile.exists()) return emptyList()
        return plan.logFile.readLines().takeLast(200)
    }

    private fun inferCrashReason(logs: List<String>): String {
        val text = logs.joinToString("\n")
        return when {
            text.contains("OutOfMemoryError") -> "内存不足：尝试增大分配内存（当前 ${"-Xmx".let { /* 从 plan 读取 */ "" }}）"
            text.contains("UnsatisfiedLinkError") -> "动态库加载失败：检查 natives 目录与 ABI 是否匹配"
            text.contains("ClassNotFoundException") -> "类找不到：依赖库可能缺失或损坏，尝试重新安装"
            text.contains("GLFW") && text.contains("failed") -> "GLFW 初始化失败：尝试切换渲染后端（Zink / GL4ES / EGL）"
            text.contains("NoClassDefFoundError") -> "类定义找不到：可能是依赖库版本冲突"
            text.contains("IncompatibleClassChangeError") -> "类不兼容：loader 与 Minecraft 版本不匹配"
            text.contains("ModResolutionException") -> "Mod 依赖冲突：检查 Mod 版本与 loader 是否兼容"
            text.contains("Could not find or load main class") -> "主类找不到：version.json 可能损坏"
            text.contains("java.lang.UnsupportedClassVersionError") -> "JRE 版本过低：当前游戏需要更高版本的 Java"
            else -> "未知崩溃，请查看完整日志"
        }
    }

    private fun saveCrashSnapshot(info: CrashInfo) {
        val snapshot = File(plan.workingDirectory, "crash-snapshot.json")
        val map = linkedMapOf(
            "exitCode" to info.exitCode,
            "reason" to info.reason,
            "timestamp" to System.currentTimeMillis(),
            "environment" to info.environment
        )
        snapshot.writeText(com.indielauncher.core.util.JsonSerializer.serialize(map))
    }
}
