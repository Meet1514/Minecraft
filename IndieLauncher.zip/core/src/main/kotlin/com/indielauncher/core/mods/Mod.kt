package com.indielauncher.core.mods

import java.io.File
import java.io.InputStream
import java.util.Properties
import java.util.zip.ZipFile

/**
 * Mod 实体。一个 Mod 对应一个 JAR 文件，附带来源、哈希与兼容信息。
 */
data class Mod(
    val id: String,
    val file: File,
    val displayName: String,
    val version: String,
    val description: String,
    val authors: List<String>,
    val loader: ModLoader,
    val gameVersions: List<String>,
    val source: ModSource,
    val sourceId: String,          // Modrinth project_id / CurseForge mod_id
    val fileId: String,            // Modrinth version_id / CurseForge file_id
    val downloadUrl: String,
    val sha1: String,
    val enabled: Boolean = true
) {
    fun fileName(): String = file.name
}

enum class ModLoader {
    FABRIC, FORGE, QUILT, UNKNOWN
}

enum class ModSource {
    MODRINTH, CURSEFORGE, LOCAL
}

/**
 * 读取 Mod 的元数据（fabric.mod.json / mods.toml / mcmod.info / pack.mcmeta）。
 */
object ModMetadataReader {

    fun read(file: File): ModInfo {
        if (!file.exists() || !file.name.endsWith(".jar")) {
            return ModInfo.unknown(file)
        }
        ZipFile(file).use { zip ->
            // Fabric: fabric.mod.json
            zip.getEntry("fabric.mod.json")?.let { entry ->
                return parseFabric(zip.getInputStream(entry).bufferedReader().readText(), file)
            }
            // Forge 1.13+: META-INF/mods.toml
            zip.getEntry("META-INF/mods.toml")?.let { entry ->
                return parseForgeModsToml(zip.getInputStream(entry), file)
            }
            // Forge 旧版: mcmod.info
            zip.getEntry("mcmod.info")?.let { entry ->
                return parseLegacyForge(zip.getInputStream(entry).bufferedReader().readText(), file)
            }
            // 资源包: pack.mcmeta
            zip.getEntry("pack.mcmeta")?.let { entry ->
                return parsePackMcmeta(zip.getInputStream(entry).bufferedReader().readText(), file)
            }
        }
        return ModInfo.unknown(file)
    }

    private fun parseFabric(jsonText: String, file: File): ModInfo {
        val json = com.indielauncher.core.util.JsonParser.parse(jsonText).asObject()
        val schema = json.optInt("schemaVersion", 1)
        val id = json.optString("id")
        val name = json.optString("name").ifBlank { id }
        val version = json.optString("version")
        val description = json.optString("description")
        val authors = (json.optArray("authors")?.iterator()?.asSequence()
            ?.map { when (it) {
                is com.indielauncher.core.util.JsonString -> it.value
                is com.indielauncher.core.util.JsonObject -> it.optString("name")
                else -> it.asString()
            } }?.toList()) ?: emptyList()
        return ModInfo(
            id = id, displayName = name, version = version,
            description = description, authors = authors,
            loader = ModLoader.FABRIC, gameVersions = emptyList(),
            file = file
        )
    }

    private fun parseForgeModsToml(input: InputStream, file: File): ModInfo {
        // mods.toml 是 TOML 格式，这里做一个极简解析
        val text = input.bufferedReader().readText()
        val modsSection = extractSection(text, "mods")
        val id = extractValue(modsSection, "modId") ?: file.nameWithoutExtension
        val name = extractValue(modsSection, "displayName") ?: id
        val description = extractValue(modsSection, "description") ?: ""
        val version = extractValue(modsSection, "version") ?: ""
        return ModInfo(
            id = id, displayName = name, version = version,
            description = description, authors = emptyList(),
            loader = ModLoader.FORGE, gameVersions = emptyList(),
            file = file
        )
    }

    private fun parseLegacyForge(jsonText: String, file: File): ModInfo {
        val json = com.indielauncher.core.util.JsonParser.parse(jsonText).asObject()
        val arr = json.optArray("modList") ?: return ModInfo.unknown(file)
        val first = arr[0] as? com.indielauncher.core.util.JsonObject ?: return ModInfo.unknown(file)
        return ModInfo(
            id = first.optString("modid"),
            displayName = first.optString("name"),
            version = first.optString("version"),
            description = first.optString("description"),
            authors = emptyList(),
            loader = ModLoader.FORGE,
            gameVersions = emptyList(),
            file = file
        )
    }

    private fun parsePackMcmeta(jsonText: String, file: File): ModInfo {
        val json = com.indielauncher.core.util.JsonParser.parse(jsonText).asObject()
        val pack = json.optObject("pack")
        val description = json.optString("description")
        val format = pack?.optInt("format", -1) ?: -1
        return ModInfo(
            id = file.nameWithoutExtension,
            displayName = file.nameWithoutExtension,
            version = "pack format $format",
            description = description,
            authors = emptyList(),
            loader = ModLoader.UNKNOWN,
            gameVersions = emptyList(),
            file = file
        )
    }

    private fun extractSection(text: String, name: String): String {
        val lines = text.lines()
        val start = lines.indexOfFirst { it.trim().startsWith("[[$name]]") || it.trim().startsWith("[$name]") }
        if (start < 0) return ""
        val end = lines.indexOfFirst { i -> i > start && i < lines.size && lines[i].trim().startsWith("[") }
        return lines.subList(start, if (end < 0) lines.size else end).joinToString("\n")
    }

    private fun extractValue(section: String, key: String): String? {
        val regex = Regex("""$key\s*=\s*"?([^"\n]*)"?""")
        return regex.find(section)?.groupValues?.get(1)?.trim()?.ifBlank { null }
    }

    data class ModInfo(
        val id: String,
        val displayName: String,
        val version: String,
        val description: String,
        val authors: List<String>,
        val loader: ModLoader,
        val gameVersions: List<String>,
        val file: File
    ) {
        companion object {
            fun unknown(file: File) = ModInfo(
                id = file.nameWithoutExtension,
                displayName = file.nameWithoutExtension,
                version = "",
                description = "",
                authors = emptyList(),
                loader = ModLoader.UNKNOWN,
                gameVersions = emptyList(),
                file = file
            )
        }
    }
}
