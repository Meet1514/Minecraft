package com.indielauncher.core.mods

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonArray
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser

/**
 * CurseForge API 客户端。
 *
 * API 文档：https://docs.curseforge.com/
 * 需要 API Key（https://console.curseforge.com/ 免费申请）。
 * 搜索参数说明：https://docs.curseforge.com/#Mods
 */
class CurseForgeApi(
    private val apiKey: String,
    private val http: HttpClient = HttpClient()
) {

    /** 搜索 Mod。 */
    fun search(
        query: String = "",
        gameId: Int = MINECRAFT_GAME_ID,
        loaderType: Int? = null,    // 见 ModLoaderType
        gameVersion: String? = null,
        classId: Int = CLASS_MODS,  // 4471 = mods
        index: Int = 0,
        pageSize: Int = 20,
        sortField: Int = SORT_POPULARITY
    ): CfSearchResult {
        val params = mutableListOf<String>()
        params.add("gameId=$gameId")
        params.add("classId=$classId")
        if (query.isNotBlank()) params.add("searchFilter=${encode(query)}")
        if (loaderType != null) params.add("modLoaderType=$loaderType")
        if (gameVersion != null) params.add("gameVersion=$gameVersion")
        params.add("index=$index")
        params.add("pageSize=$pageSize")
        params.add("sortField=$sortField")
        params.add("sortOrder=desc")

        val url = "$BASE_URL/mods/search?" + params.joinToString("&")
        val req = requestBuilder(url).GET().build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        val json = JsonParser.parse(resp.body() ?: "").asObject()
        return parseSearchResult(json)
    }

    /** 获取 Mod 详情。 */
    fun getMod(modId: Int): CfMod {
        val url = "$BASE_URL/mods/$modId"
        val req = requestBuilder(url).GET().build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        val json = JsonParser.parse(resp.body() ?: "").asObject()
        return parseMod(json.optObject("data")!!)
    }

    /** 获取 Mod 的文件列表（版本）。 */
    fun getModFiles(
        modId: Int,
        gameVersion: String? = null,
        index: Int = 0,
        pageSize: Int = 50
    ): List<CfFile> {
        val params = mutableListOf<String>()
        if (gameVersion != null) params.add("gameVersion=$gameVersion")
        params.add("index=$index")
        params.add("pageSize=$pageSize")
        val url = "$BASE_URL/mods/$modId/files?" + params.joinToString("&")
        val req = requestBuilder(url).GET().build()
        val resp = http.client.send(req, java.net.http.HttpResponse.BodyHandlers.ofString())
        val json = JsonParser.parse(resp.body() ?: "").asObject()
        val arr = json.optArray("data") ?: JsonArray()
        return arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map { parseFile(it) }
            .toList()
    }

    private fun parseSearchResult(json: JsonObject): CfSearchResult {
        val arr = json.optArray("data") ?: JsonArray()
        val list = arr.iterator().asSequence()
            .filterIsInstance<JsonObject>()
            .map { parseMod(it) }
            .toList()
        return CfSearchResult(
            total = json.optInt("pagination", 0).let { json.optObject("pagination")?.optInt("totalCount") ?: list.size },
            mods = list
        )
    }

    private fun parseMod(obj: JsonObject): CfMod {
        val links = obj.optObject("links")
        return CfMod(
            id = obj.optInt("id"),
            name = obj.optString("name"),
            slug = obj.optString("slug"),
            summary = obj.optString("summary"),
            authors = (obj.optArray("authors")?.iterator()?.asSequence()
                ?.filterIsInstance<JsonObject>()
                ?.map { it.optString("name") }?.toList()) ?: emptyList(),
            logoUrl = obj.optObject("logo")?.optString("url") ?: "",
            websiteUrl = links?.optString("websiteUrl") ?: "",
            downloadCount = obj.optLong("downloadCount"),
            latestFiles = (obj.optArray("latestFiles")?.iterator()?.asSequence()
                ?.filterIsInstance<JsonObject>()
                ?.map { parseFile(it) }?.toList()) ?: emptyList()
        )
    }

    private fun parseFile(obj: JsonObject): CfFile {
        return CfFile(
            id = obj.optInt("id"),
            modId = obj.optInt("modId"),
            displayName = obj.optString("displayName"),
            fileName = obj.optString("fileName"),
            downloadUrl = obj.optString("downloadUrl"),  // 可能为 null，需走 /download-url
            fileLength = obj.optLong("fileLength"),
            releaseType = obj.optInt("releaseType"),  // 1=release 2=beta 3=alpha
            gameVersions = obj.optArray("gameVersions")?.asStringList() ?: emptyList(),
            modLoader = obj.optInt("modLoader"),
            sha1 = obj.optString("hashes").let { h ->
                val ha = obj.optArray("hashes")?.iterator()?.asSequence()
                    ?.filterIsInstance<JsonObject>()
                    ?.firstOrNull { it.optInt("algo") == 1 } // 1 = sha1
                ha?.optString("value") ?: ""
            }
        )
    }

    private fun requestBuilder(url: String): java.net.http.HttpRequest.Builder =
        java.net.http.HttpRequest.newBuilder()
            .uri(java.net.URI.create(url))
            .header("x-api-key", apiKey)
            .header("Accept", "application/json")

    private fun encode(s: String): String =
        java.net.URLEncoder.encode(s, Charsets.UTF_8.name())

    companion object {
        const val BASE_URL = "https://api.curseforge.com/v1"
        const val MINECRAFT_GAME_ID = 432
        const val CLASS_MODS = 6

        // ModLoaderType（CurseForge 枚举）
        const val LOADER_ANY = 0
        const val LOADER_FORGE = 1
        const val LOADER_CAULDRON = 2
        const val LOADER_LITELOADER = 3
        const val LOADER_FABRIC = 4
        const val LOADER_QUILT = 5
        const val LOADER_NEOFORGE = 6

        // SortField
        const val SORT_POPULARITY = 1
        const val SORT_LAST_UPDATED = 2
        const val SORT_NAME = 3
        const val SORT_AUTHOR = 4
        const val SORT_TOTAL_DOWNLOADS = 5
    }
}

data class CfSearchResult(
    val total: Int,
    val mods: List<CfMod>
)

data class CfMod(
    val id: Int,
    val name: String,
    val slug: String,
    val summary: String,
    val authors: List<String>,
    val logoUrl: String,
    val websiteUrl: String,
    val downloadCount: Long,
    val latestFiles: List<CfFile>
)

data class CfFile(
    val id: Int,
    val modId: Int,
    val displayName: String,
    val fileName: String,
    val downloadUrl: String?,
    val fileLength: Long,
    val releaseType: Int,
    val gameVersions: List<String>,
    val modLoader: Int,
    val sha1: String
)
