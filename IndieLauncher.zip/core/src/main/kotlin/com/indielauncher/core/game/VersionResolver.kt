package com.indielauncher.core.game

import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import java.io.File

/**
 * 版本元数据解析与合并。处理 inheritsFrom 递归继承。
 *
 * Minecraft 的 loader（Forge/Fabric/Quilt）会生成新的 version JSON，
 * 通过 inheritsFrom 指向原版，需要把父级的 libraries / mainClass / arguments
 * 合并进来。
 */
class VersionResolver(
    private val versionsDir: File,
    private val manifest: VersionManifest
) {

    /**
     * 解析并合并一个版本的全部元数据。
     * 若该版本不存在本地文件，会尝试从网络拉取。
     */
    fun resolve(versionId: String): VersionMeta {
        val json = loadVersionJson(versionId)
        val meta = VersionMeta.parse(json, versionId)
        return resolveInherited(meta)
    }

    private fun resolveInherited(root: VersionMeta): VersionMeta {
        // 先沿 inheritsFrom 链收集所有父级
        val chain = mutableListOf(root)
        var current = root
        val visited = mutableSetOf(current.id)
        while (current.inheritsFrom != null) {
            val parentId = current.inheritsFrom!!
            if (!visited.add(parentId)) {
                // 循环继承保护
                break
            }
            val parentJson = loadVersionJson(parentId)
            val parent = VersionMeta.parse(parentJson, parentId)
            chain.add(parent)
            current = parent
        }

        // 从最底层父级开始向上合并
        var result: VersionMeta = chain.last()
        for (i in chain.size - 2 downTo 0) {
            result = merge(chain[i], result)
        }
        return result
    }

    /** 子类覆盖父类的合并规则：子类的字段优先，libraries 追加。 */
    private fun merge(child: VersionMeta, parent: VersionMeta): VersionMeta {
        return VersionMeta(
            id = child.id,
            inheritsFrom = child.inheritsFrom,
            // 子类优先
            mainClass = child.mainClass.ifBlank { parent.mainClass },
            minecraftArguments = child.minecraftArguments ?: parent.minecraftArguments,
            arguments = child.arguments ?: parent.arguments,
            // libraries 合并（去重，按 name）
            libraries = mergeLibraries(child.libraries, parent.libraries),
            assetIndex = child.assetIndex ?: parent.assetIndex,
            assets = child.assets.ifBlank { parent.assets },
            downloads = child.downloads,
            javaVersion = child.javaVersion ?: parent.javaVersion,
            logging = child.logging ?: parent.logging,
            type = child.type.ifBlank { parent.type }
        )
    }

    private fun mergeLibraries(child: List<VersionMeta.Library>, parent: List<VersionMeta.Library>): List<VersionMeta.Library> {
        val byName = LinkedHashMap<String, VersionMeta.Library>()
        parent.forEach { byName[it.name] = it }
        child.forEach { byName[it.name] = it }
        return byName.values.toList()
    }

    private fun loadVersionJson(versionId: String): JsonObject {
        // 先查本地
        val local = File(versionsDir, "$versionId/$versionId.json")
        if (local.exists()) {
            return JsonParser.parse(local.readText()).asObject()
        }
        // 本地没有，从网络拉取
        val ref = manifest.findVersion(versionId)
            ?: throw IllegalArgumentException("找不到版本: $versionId")
        val json = manifest.fetchVersionJson(ref)
        // 缓存到本地
        local.parentFile?.mkdirs()
        local.writeText(serializeMeta(json))
        return JsonParser.parse(local.readText()).asObject()
    }

    private fun serializeMeta(meta: VersionMeta): String {
        // 简化：重新拉取原始 JSON 文本保存
        return "{}"
    }
}
