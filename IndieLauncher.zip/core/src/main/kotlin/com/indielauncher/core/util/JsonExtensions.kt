package com.indielauncher.core.util

/**
 * JsonObject 序列化辅助。把任意对象树转成 JSON 字符串。
 * 用于保存 profile、managed-mods.json 等配置文件。
 */
object JsonSerializer {

    fun serialize(element: Any?): String = buildString { write(element) }

    private fun StringBuilder.write(value: Any?) {
        when (value) {
            null -> append("null")
            is String -> append(JsonString(value))
            is Number -> append(value.toString())
            is Boolean -> append(value.toString())
            is JsonElement -> append(value.toString())
            is Map<*, *> -> {
                append('{')
                var first = true
                for ((k, v) in value) {
                    if (!first) append(',')
                    append('"').append(k.toString()).append('"').append(':')
                    write(v)
                    first = false
                }
                append('}')
            }
            is Collection<*> -> {
                append('[')
                var first = true
                for (item in value) {
                    if (!first) append(',')
                    write(item)
                    first = false
                }
                append(']')
            }
            is Array<*> -> {
                append('[')
                var first = true
                for (item in value) {
                    if (!first) append(',')
                    write(item)
                    first = first
                    first = false
                }
                append(']')
            }
            else -> append('"').append(value.toString()).append('"')
        }
    }

    /** 解析后转为普通 Map/List，方便 Kotlin 侧使用。 */
    fun toNativeTree(element: JsonElement): Any? = when (element) {
        is JsonObject -> element.entries.associate { it.key to toNativeTree(it.value) }
        is JsonArray -> element.iterator().asSequence().map { toNativeTree(it) }.toList()
        is JsonString -> element.value
        is JsonNumber -> element.value.toDouble()
        is JsonBoolean -> element.value
        JsonNull -> null
    }
}
