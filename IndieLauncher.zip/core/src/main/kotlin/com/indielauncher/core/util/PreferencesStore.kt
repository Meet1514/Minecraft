package com.indielauncher.core.util

import java.io.File
import java.util.Properties

/**
 * 轻量偏好存储，基于 Properties 文件。Android 侧会替换为 DataStore 实现。
 */
class PreferencesStore(
    private val file: File
) {

    private val props = Properties()

    constructor(dir: File) : this(File(dir, "prefs.properties"))

    init {
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.createNewFile()
        }
        load()
    }

    @Synchronized
    private fun load() {
        file.inputStream().use { props.load(it) }
    }

    @Synchronized
    private fun save() {
        file.outputStream().use { props.store(it, "IndieLauncher preferences") }
    }

    fun getString(key: String, default: String = ""): String =
        props.getProperty(key, default) ?: default

    fun putString(key: String, value: String) {
        props.setProperty(key, value)
        save()
    }

    fun getInt(key: String, default: Int = 0): Int =
        props.getProperty(key)?.toIntOrNull() ?: default

    fun putInt(key: String, value: Int) {
        props.setProperty(key, value.toString())
        save()
    }

    fun getBoolean(key: String, default: Boolean = false): Boolean =
        props.getProperty(key)?.toBoolean() ?: default

    fun putBoolean(key: String, value: Boolean) {
        props.setProperty(key, value.toString())
        save()
    }

    fun getLong(key: String, default: Long = 0L): Long =
        props.getProperty(key)?.toLongOrNull() ?: default

    fun putLong(key: String, value: Long) {
        props.setProperty(key, value.toString())
        save()
    }

    fun remove(key: String) {
        props.remove(key)
        save()
    }

    companion object {
        const val KEY_DEFAULT_RUNTIME = "default.runtime.id"
        const val KEY_DEFAULT_RENDERER = "default.renderer.id"
        const val KEY_DEFAULT_MEMORY_MB = "default.memory.mb"
        const val KEY_DOWNLOAD_MIRROR = "download.mirror"
        const val KEY_MICROSOFT_CLIENT_ID = "auth.microsoft.client_id"
        const val KEY_TELEMETRY_ENABLED = "telemetry.enabled"
        const val KEY_LAST_LAUNCH_PROFILE = "last.launch.profile"
    }
}
