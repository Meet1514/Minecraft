package com.indielauncher.core.download

import com.indielauncher.core.util.HttpClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicLong

/**
 * 下载任务状态。
 * 对应调研报告中的状态机：Pending -> Resolving -> Downloading -> Verifying -> Unpacking -> Completed
 */
enum class TaskState {
    PENDING, RUNNING, COMPLETED, FAILED, CANCELLED
}

data class DownloadTask(
    val url: String,
    val dest: File,
    val expectedSha1: String? = null,
    val expectedSha256: String? = null,
    val algorithm: String = "sha-1",
    val size: Long = -1L,
    val tag: String = "",
    var state: TaskState = TaskState.PENDING,
    var progress: Long = 0L,
    var total: Long = -1L,
    var error: String? = null
)

/**
 * 并发下载管理器。
 *
 * 设计要点：
 *  - 固定并发数（Semaphore），避免同时开几百个连接
 *  - 全局进度聚合（totalBytes / downloadedBytes / activeCount）
 *  - 失败可重试，支持整体取消
 *  - 每个任务原子落盘（.part 临时文件），失败可断点续传
 */
class DownloadManager(
    private val http: HttpClient = HttpClient(),
    private val maxConcurrency: Int = 6
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val semaphore = Semaphore(maxConcurrency)

    private val queue = ConcurrentLinkedQueue<DownloadTask>()
    private val tasks = mutableListOf<DownloadTask>()
    private val jobs = mutableMapOf<DownloadTask, Job>()

    private val _tasksState = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasksState: StateFlow<List<DownloadTask>> = _tasksState.asStateFlow()

    private val _globalProgress = MutableStateFlow(GlobalProgress())
    val globalProgress: StateFlow<GlobalProgress> = _globalProgress.asStateFlow()

    private val totalBytes = AtomicLong(0L)
    private val downloadedBytes = AtomicLong(0L)

    fun submit(task: DownloadTask): DownloadTask {
        queue.offer(task)
        synchronized(tasks) { tasks.add(task) }
        emitTasks()
        startWorker()
        return task
    }

    fun submitAll(newTasks: List<DownloadTask>) {
        newTasks.forEach { queue.offer(it) }
        synchronized(tasks) { tasks.addAll(newTasks) }
        emitTasks()
        repeat(maxConcurrency) { startWorker() }
    }

    fun cancelAll() {
        synchronized(jobs) { jobs.values.forEach { it.cancel() } }
        queue.clear()
    }

    private fun startWorker() {
        scope.launch {
            semaphore.acquire()
            try {
                while (true) {
                    val task = queue.poll() ?: break
                    runTask(task)
                }
            } finally {
                semaphore.release()
            }
        }
    }

    private fun runTask(task: DownloadTask) {
        task.state = TaskState.RUNNING
        val job = scope.launch {
            try {
                http.download(
                    url = task.url,
                    dest = task.dest,
                    expectedSha1 = task.expectedSha1,
                    expectedSha256 = task.expectedSha256,
                    algorithm = task.algorithm
                ) { progress, total ->
                    task.progress = progress
                    task.total = if (total > 0) total else task.size
                    if (task.total > 0) totalBytes.addAndGet(0)
                    updateGlobal()
                    emitTasks()
                }
                task.state = TaskState.COMPLETED
                task.progress = task.dest.length()
                downloadedBytes.addAndGet(task.dest.length())
                updateGlobal()
            } catch (t: Throwable) {
                task.state = TaskState.FAILED
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                synchronized(jobs) { jobs.remove(task) }
                emitTasks()
            }
        }
        synchronized(jobs) { jobs[task] = job }
    }

    private fun updateGlobal() {
        val active = tasks.count { it.state == TaskState.RUNNING }
        val done = tasks.count { it.state == TaskState.COMPLETED }
        val failed = tasks.count { it.state == TaskState.FAILED }
        val total = tasks.size
        _globalProgress.value = GlobalProgress(
            totalTasks = total,
            activeCount = active,
            completedCount = done,
            failedCount = failed,
            totalBytes = tasks.map { if (it.total > 0) it.total else 0L }.sum(),
            downloadedBytes = tasks.sumOf { it.progress }
        )
    }

    private fun emitTasks() {
        synchronized(tasks) {
            _tasksState.value = tasks.toList()
        }
    }

    fun isAllCompleted(): Boolean = tasks.isNotEmpty() &&
        tasks.none { it.state == TaskState.PENDING || it.state == TaskState.RUNNING }

    fun hasFailures(): Boolean = tasks.any { it.state == TaskState.FAILED }
}

data class GlobalProgress(
    val totalTasks: Int = 0,
    val activeCount: Int = 0,
    val completedCount: Int = 0,
    val failedCount: Int = 0,
    val totalBytes: Long = 0L,
    val downloadedBytes: Long = 0L
) {
    val fraction: Float get() = if (totalBytes <= 0L) 0f else (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
    val isFinished: Boolean get() = totalTasks > 0 && activeCount == 0
}
