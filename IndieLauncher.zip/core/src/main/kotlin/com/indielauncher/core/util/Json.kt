package com.indielauncher.core.util

/**
 * 自研极简 JSON 解析器，避免引入第三方依赖。
 *
 * 支持：对象、数组、字符串、数字、布尔、null。
 * 覆盖 Minecraft 版本元数据所需的所有场景。
 */
sealed class JsonElement {
    abstract fun asString(): String
    abstract fun asBoolean(): Boolean
    abstract fun asLong(): Long
    abstract fun asInt(): Int
    abstract fun asDouble(): Double

    fun asObject(): JsonObject = this as? JsonObject
        ?: throw IllegalStateException("Expected JsonObject but was $this")

    fun asArray(): JsonArray = this as? JsonArray
        ?: throw IllegalStateException("Expected JsonArray but was $this")

    open fun optString(name: String, default: String = ""): String = default
    open fun optBoolean(name: String, default: Boolean = false): Boolean = default
    open fun optLong(name: String, default: Long = 0L): Long = default
    open fun optInt(name: String, default: Int = 0): Int = default
    open fun optDouble(name: String, default: Double = 0.0): Double = default
    open fun optObject(name: String): JsonObject? = null
    open fun optArray(name: String): JsonArray? = null
    open fun has(name: String): Boolean = false

    open fun getOrNull(name: String): JsonElement? = null
}

class JsonObject : JsonElement() {
    private val map: MutableMap<String, JsonElement> = LinkedHashMap()

    val entries: Set<Map.Entry<String, JsonElement>> get() = map.entries
    val size: Int get() = map.size

    fun put(key: String, value: JsonElement) { map[key] = value }

    override fun optString(name: String, default: String): String {
        val v = map[name] ?: return default
        return if (v is JsonString) v.value else default
    }

    override fun optBoolean(name: String, default: Boolean): Boolean {
        val v = map[name] ?: return default
        return if (v is JsonBoolean) v.value else default
    }

    override fun optLong(name: String, default: Long): Long {
        val v = map[name] ?: return default
        return when (v) {
            is JsonNumber -> v.value.toLong()
            is JsonString -> v.value.toLongOrNull() ?: default
            else -> default
        }
    }

    override fun optInt(name: String, default: Int): Int = optLong(name, default.toLong()).toInt()

    override fun optDouble(name: String, default: Double): Double {
        val v = map[name] ?: return default
        return when (v) {
            is JsonNumber -> v.value.toDouble()
            is JsonString -> v.value.toDoubleOrNull() ?: default
            else -> default
        }
    }

    override fun optObject(name: String): JsonObject? = map[name] as? JsonObject
    override fun optArray(name: String): JsonArray? = map[name] as? JsonArray
    override fun has(name: String): Boolean = map.containsKey(name)
    override fun getOrNull(name: String): JsonElement? = map[name]

    operator fun get(name: String): JsonElement = map[name]
        ?: throw NoSuchElementException("JSON key '$name' not found")

    fun keys(): Set<String> = map.keys

    override fun asString(): String = throw UnsupportedOperationException("JsonObject cannot be string")
    override fun asBoolean(): Boolean = throw UnsupportedOperationException("JsonObject cannot be boolean")
    override fun asLong(): Long = throw UnsupportedOperationException("JsonObject cannot be long")
    override fun asInt(): Int = throw UnsupportedOperationException("JsonObject cannot be int")
    override fun asDouble(): Double = throw UnsupportedOperationException("JsonObject cannot be double")

    override fun toString(): String = buildString {
        append('{')
        var first = true
        for ((k, v) in map) {
            if (!first) append(',')
            append('"').append(k).append('"').append(':').append(v)
            first = false
        }
        append('}')
    }
}

class JsonArray : JsonElement() {
    private val list: MutableList<JsonElement> = ArrayList()

    val size: Int get() = list.size
    fun isEmpty(): Boolean = list.isEmpty()

    fun add(element: JsonElement) { list.add(element) }

    operator fun get(index: Int): JsonElement = list[index]
    override fun getOrNull(name: String): JsonElement? = null
    fun iterator(): Iterator<JsonElement> = list.iterator()

    fun asStringList(): List<String> = list.mapNotNull { (it as? JsonString)?.value }
    fun asObjectList(): List<JsonObject> = list.mapNotNull { it as? JsonObject }

    override fun asString(): String = throw UnsupportedOperationException("JsonArray cannot be string")
    override fun asBoolean(): Boolean = throw UnsupportedOperationException("JsonArray cannot be boolean")
    override fun asLong(): Long = throw UnsupportedOperationException("JsonArray cannot be long")
    override fun asInt(): Int = throw UnsupportedOperationException("JsonArray cannot be int")
    override fun asDouble(): Double = throw UnsupportedOperationException("JsonArray cannot be double")

    override fun toString(): String = list.joinToString(",", "[", "]")
}

class JsonString(val value: String) : JsonElement() {
    override fun asString(): String = value
    override fun asBoolean(): Boolean = value.isNotEmpty()
    override fun asLong(): Long = value.toLongOrNull() ?: 0L
    override fun asInt(): Int = value.toIntOrNull() ?: 0
    override fun asDouble(): Double = value.toDoubleOrNull() ?: 0.0
    override fun toString(): String = '"' + value.replace("\\", "\\\\").replace("\"", "\\\"") + '"'
}

class JsonNumber(val value: String) : JsonElement() {
    override fun asString(): String = value
    override fun asBoolean(): Boolean = value.toDoubleOrNull()?.let { it != 0.0 } ?: false
    override fun asLong(): Long = value.toLongOrNull() ?: 0L
    override fun asInt(): Int = value.toIntOrNull() ?: 0
    override fun asDouble(): Double = value.toDoubleOrNull() ?: 0.0
    override fun toString(): String = value
}

class JsonBoolean(val value: Boolean) : JsonElement() {
    override fun asString(): String = value.toString()
    override fun asBoolean(): Boolean = value
    override fun asLong(): Long = if (value) 1L else 0L
    override fun asInt(): Int = if (value) 1 else 0
    override fun asDouble(): Double = if (value) 1.0 else 0.0
    override fun toString(): String = value.toString()
}

object JsonNull : JsonElement() {
    override fun asString(): String = ""
    override fun asBoolean(): Boolean = false
    override fun asLong(): Long = 0L
    override fun asInt(): Int = 0
    override fun asDouble(): Double = 0.0
    override fun toString(): String = "null"
}

object JsonParser {

    fun parse(input: String): JsonElement = parse(input.toCharArray())

    fun parse(chars: CharArray): JsonElement {
        val p = Parser(chars)
        p.skipWhitespace()
        val result = p.parseValue()
        p.skipWhitespace()
        return result
    }

    private class Parser(private val src: CharArray) {
        private var p: Int = 0

        fun parseValue(): JsonElement {
            return when (val c = peek()) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> JsonString(parseString())
                't', 'f' -> JsonBoolean(parseKeyword())
                'n' -> { advance(4); JsonNull }
                '-', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' -> JsonNumber(parseNumber())
                else -> throw IllegalStateException("Unexpected character '$c' at $p")
            }
        }

        private fun parseObject(): JsonObject {
            advance(1)
            val obj = JsonObject()
            skipWhitespace()
            if (peek() == '}') { advance(1); return obj }
            while (true) {
                skipWhitespace()
                val key = parseString()
                skipWhitespace()
                expect(':')
                skipWhitespace()
                val value = parseValue()
                obj.put(key, value)
                skipWhitespace()
                if (peek() == ',') { advance(1); continue }
                if (peek() == '}') { advance(1); return obj }
                throw IllegalStateException("Expected ',' or '}' at $p")
            }
        }

        private fun parseArray(): JsonArray {
            advance(1)
            val arr = JsonArray()
            skipWhitespace()
            if (peek() == ']') { advance(1); return arr }
            while (true) {
                skipWhitespace()
                val value = parseValue()
                arr.add(value)
                skipWhitespace()
                if (peek() == ',') { advance(1); continue }
                if (peek() == ']') { advance(1); return arr }
                throw IllegalStateException("Expected ',' or ']' at $p")
            }
        }

        private fun parseString(): String {
            advance(1)
            val sb = StringBuilder()
            while (p < src.size) {
                val c = src[p]
                when {
                    c == '"' -> { advance(1); return sb.toString() }
                    c == '\\' -> {
                        advance(1)
                        if (p >= src.size) throw IllegalStateException("Unexpected end in escape")
                        sb.append(when (val e = src[p]) {
                            '"' -> '"'; '\\' -> '\\'; '/' -> '/'
                            'b' -> '\b'; 'f' -> '\u000C'; 'n' -> '\n'
                            'r' -> '\r'; 't' -> '\t'
                            'u' -> {
                                advance(1)
                                if (p + 4 > src.size) throw IllegalStateException("Invalid unicode escape")
                                val code = String(src, p, 4).toInt(16)
                                advance(3)
                                code.toChar()
                            }
                            else -> throw IllegalStateException("Invalid escape '\\$e'")
                        })
                        advance(1)
                    }
                    c.code < 0x20 -> throw IllegalStateException("Unexpected control character in string")
                    else -> { sb.append(c); advance(1) }
                }
            }
            throw IllegalStateException("Unterminated string")
        }

        private fun parseKeyword(): Boolean {
            if (match("true")) return true
            if (match("false")) return false
            throw IllegalStateException("Invalid keyword at $p")
        }

        private fun match(s: String): Boolean {
            if (p + s.length > src.size) return false
            for (i in s.indices) {
                if (src[p + i] != s[i]) return false
            }
            advance(s.length)
            return true
        }

        private fun parseNumber(): String {
            val start = p
            if (peek() == '-') advance(1)
            while (p < src.size && src[p] in '0'..'9') advance(1)
            if (peek() == '.') {
                advance(1)
                while (p < src.size && src[p] in '0'..'9') advance(1)
            }
            if (peek() == 'e' || peek() == 'E') {
                advance(1)
                if (peek() == '+' || peek() == '-') advance(1)
                while (p < src.size && src[p] in '0'..'9') advance(1)
            }
            return String(src, start, p - start)
        }

        fun skipWhitespace() {
            while (p < src.size) {
                when (peek()) {
                    ' ', '\t', '\n', '\r' -> advance(1)
                    else -> return
                }
            }
        }

        private fun peek(): Char = if (p < src.size) src[p] else '\u0000'
        private fun advance(n: Int) { p += n }
        private fun expect(c: Char) {
            if (peek() != c) throw IllegalStateException("Expected '$c' at $p but found '${peek()}'")
            advance(1)
        }
    }
}
