package com.indielauncher.core.util

import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/**
 * 哈希校验工具。Minecraft 官方库/资源普遍使用 SHA-1，
 * 部分运行时清单使用 SHA-256，因此两种都支持。
 */
object Hash {

    fun sha1(file: File): String = file.inputStream().use { sha1(it) }
    fun sha256(file: File): String = file.inputStream().use { sha256(it) }

    fun sha1(input: InputStream): String = digest("SHA-1", input)
    fun sha256(input: InputStream): String = digest("SHA-256", input)

    private fun digest(algorithm: String, input: InputStream): String {
        val md = MessageDigest.getInstance(algorithm)
        val buffer = ByteArray(8192)
        var read: Int
        while (input.read(buffer).also { read = it } != -1) {
            md.update(buffer, 0, read)
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** 校验文件哈希，expected 为空/blank 时视为不校验（返回 true）。 */
    fun verify(file: File, algorithm: String, expected: String?): Boolean {
        if (expected.isNullOrBlank()) return true
        val actual = when (algorithm.lowercase()) {
            "sha-256", "sha256" -> sha256(file)
            else -> sha1(file)
        }
        return actual.equals(expected, ignoreCase = true)
    }
}
