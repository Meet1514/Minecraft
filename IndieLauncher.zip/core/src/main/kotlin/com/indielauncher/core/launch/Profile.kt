package com.indielauncher.core.launch

import com.indielauncher.core.auth.Account
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.JsonSerializer
import java.io.File

/**
 * 游戏实例（Profile）配置。
 *
 * 每个 Profile 对应一个独立的游戏目录，包含自己的 mods/、resourcepacks/、
 * shaderpacks/、config/、options.txt 等，互不污染。
 */
data class Profile(
    val id: String,
    val name: String,
    val gameDir: File,
    val versionId: String,              // 游戏版本（原版或 loader 生成的）
    val loader: String? = null,          // fabric / forge / quilt / null
    val loaderVersion: String? = null,
    val runtimeId: String? = null,       // 使用的 JRE 运行时 id
    val rendererId: String = "zink",    // 渲染后端
    val memoryMb: Int = 2048,           // 最大内存
    val javaArgs: List<String> = emptyList(),
    val gameArgs: List<String> = emptyList(),
    val resolution: Resolution = Resolution(),
    val scaleFactor: Float = 1.0f,
    val lastPlayed: Long = 0L,
    val iconPath: String? = null
) {
    fun save(dir: File) {
        dir.mkdirs()
        val map = linkedMapOf(
            "schemaVersion" to 3,
            "profileId" to id,
            "name" to name,
            "versionId" to versionId,
            "loader" to (loader ?: ""),
            "loaderVersion" to (loaderVersion ?: ""),
            "runtimeId" to (runtimeId ?: ""),
            "renderer" to rendererId,
            "memory" to linkedMapOf(
                "xmxMb" to memoryMb,
                "xmsMb" to (memoryMb / 2).coerceAtLeast(512)
            ),
            "resolution" to linkedMapOf(
                "width" to resolution.width,
                "height" to resolution.height,
                "auto" to resolution.auto
            ),
            "javaArgs" to javaArgs,
            "gameArgs" to gameArgs,
            "scaleFactor" to scaleFactor,
            "lastPlayed" to lastPlayed,
            "iconPath" to (iconPath ?: "")
        )
        File(dir, "$id.json").writeText(JsonSerializer.serialize(map))
    }

    companion object {
        fun load(file: File): Profile {
            val json = JsonParser.parse(file.readText()).asObject()
            val mem = json.optObject("memory")
            val res = json.optObject("resolution")
            return Profile(
                id = json.optString("profileId", file.nameWithoutExtension),
                name = json.optString("name", json.optString("profileId")),
                gameDir = File(json.optString("gameDir", "")).takeIf { it.path.isNotEmpty() }
                    ?: File(file.parentFile, json.optString("profileId")),
                versionId = json.optString("versionId"),
                loader = json.optString("loader").ifBlank { null },
                loaderVersion = json.optString("loaderVersion").ifBlank { null },
                runtimeId = json.optString("runtimeId").ifBlank { null },
                rendererId = json.optString("renderer", "zink"),
                memoryMb = mem?.optInt("xmxMb", 2048) ?: 2048,
                javaArgs = json.optArray("javaArgs")?.asStringList() ?: emptyList(),
                gameArgs = json.optArray("gameArgs")?.asStringList() ?: emptyList(),
                resolution = Resolution(
                    width = res?.optInt("width", 0) ?: 0,
                    height = res?.optInt("height", 0) ?: 0,
                    auto = res?.optBoolean("auto", true) ?: true
                ),
                scaleFactor = json.optDouble("scaleFactor", 1.0).toFloat(),
                lastPlayed = json.optLong("lastPlayed"),
                iconPath = json.optString("iconPath").ifBlank { null }
            )
        }
    }
}

data class Resolution(
    val width: Int = 0,
    val height: Int = 0,
    val auto: Boolean = true
)
