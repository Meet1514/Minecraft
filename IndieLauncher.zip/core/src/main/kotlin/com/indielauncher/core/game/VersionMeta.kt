package com.indielauncher.core.game

import com.indielauncher.core.util.JsonArray
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.Os

/**
 * 单个版本的元数据（version.json 解析结果）。
 *
 * 新版（1.13+）使用 `arguments` 字段，旧版使用 `minecraftArguments` 字符串。
 * 支持 `inheritsFrom` 递归继承父版本。
 */
class VersionMeta private constructor(
    val id: String,
    val inheritsFrom: String?,
    val mainClass: String,
    val minecraftArguments: String?,
    val arguments: Arguments?,
    val libraries: List<Library>,
    val assetIndex: AssetIndex?,
    val assets: String,
    val downloads: Downloads,
    val javaVersion: Int?,
    val logging: LoggingConfig?,
    val type: String
) {

    /** 依赖库 */
    data class Library(
        val name: String,                     // Maven 坐标: group:artifact:version
        val url: String = MOJANG_LIBRARIES,   // 下载源
        val rules: List<Rule> = emptyList(),  // 兼容性规则
        val natives: Map<String, String> = emptyMap(), // classifier 映射
        val extractExcludes: List<String> = emptyList(),
        val downloads: LibraryDownloads? = null, // 新版有独立下载信息
        val sha1: String? = null
    ) {
        /** 判断是否适用于当前平台 */
        fun applies(): Boolean {
            if (rules.isEmpty()) return true
            var allowed = false
            for (rule in rules) {
                if (rule.matches()) allowed = rule.action == Rule.ALLOW
            }
            return allowed
        }

        /** 获取 natives classifier（针对当前 ABI）。返回 null 表示不需要 natives。 */
        fun nativeClassifier(): String? {
            val os = Os.currentName()
            val classifier = natives[os] ?: return null
            // Android 上把 linux 的 natives 替换掉，由 runtime-ffi 提供 GLFW/OpenAL
            if (Os.isAndroid) return null
            return classifier
        }

        fun mavenPath(): String {
            val parts = name.split(':')
            if (parts.size < 3) return name
            val group = parts[0].replace('.', '/')
            val artifact = parts[1]
            val version = parts[2]
            val classifier = if (parts.size > 3) "-${parts[3]}" else ""
            return "$group/$artifact/$version/$artifact-$version$classifier.jar"
        }

        /** 文件在本地的相对路径（相对 librariesDir） */
        fun localPath(): String = mavenPath()

        fun downloadUrl(): String = downloads?.artifact?.url ?: "$url${mavenPath()}"
        fun expectedSha1(): String? = downloads?.artifact?.sha1 ?: sha1
        fun size(): Long = downloads?.artifact?.size ?: -1L
    }

    data class Rule(
        val action: String, // "allow" | "disallow"
        val os: OsRule?,
        val features: Map<String, Boolean>?
    ) {
        fun matches(): Boolean {
            if (os != null && !os.matches()) return false
            // features 判断：目前只识别 is_demo_user
            features?.forEach { (k, v) ->
                if (k == "is_demo_user" && v) return false
            }
            return true
        }

        companion object {
            const val ALLOW = "allow"
        }
    }

    data class OsRule(
        val name: String?,
        val version: String?,
        val arch: String?
    ) {
        fun matches(): Boolean {
            if (name != null && name != Os.currentName()) return false
            // version/arch 正则匹配较复杂，这里简化处理：只做精确匹配
            if (arch != null && arch != Os.nativeArch()) return false
            return true
        }
    }

    data class Arguments(
        val game: List<Arg>,
        val jvm: List<Arg>
    )

    sealed class Arg {
        data class StringArg(val value: String) : Arg()
        data class RuleArg(val rules: List<Rule>, val value: Any) : Arg()

        companion object {
            fun from(json: Any): Arg = when (json) {
                is String -> StringArg(json)
                is JsonObject -> {
                    val rules = (json.optArray("rules")?.iterator()?.asSequence()
                        ?.filterIsInstance<JsonObject>()
                        ?.map { parseRule(it) }?.toList()) ?: emptyList()
                    RuleArg(rules, json.getOrNull("value") ?: "")
                }
                else -> StringArg(json.toString())
            }
        }
    }

    data class AssetIndex(
        val id: String,
        val url: String,
        val size: Long,
        val totalSize: Long,
        val sha1: String
    )

    data class Downloads(
        val client: ArtifactInfo?,
        val clientMappings: ArtifactInfo?,
        val server: ArtifactInfo?,
        val serverMappings: ArtifactInfo?
    )

    data class ArtifactInfo(
        val url: String,
        val sha1: String,
        val size: Long
    )

    data class LibraryDownloads(
        val artifact: ArtifactInfo?,
        val classifiers: Map<String, ArtifactInfo>?
    )

    data class LoggingConfig(
        val file: ArtifactInfo,
        val argument: String,
        val type: String
    )

    companion object {
        const val MOJANG_LIBRARIES = "https://libraries.minecraft.net/"

        fun parse(json: JsonObject, versionId: String): VersionMeta {
            val inheritsFrom = json.optString("inheritsFrom").ifBlank { null }

            // arguments（新版）或 minecraftArguments（旧版）
            val arguments = json.optObject("arguments")?.let { parseArguments(it) }
            val minecraftArguments = json.optString("minecraftArguments").ifBlank { null }

            // libraries
            val libsArr = json.optArray("libraries") ?: JsonArray()
            val libraries = libsArr.iterator().asSequence()
                .filterIsInstance<JsonObject>()
                .map { parseLibrary(it) }
                .toList()

            // asset index
            val assetIndex = json.optObject("assetIndex")?.let {
                AssetIndex(
                    id = it.optString("id"),
                    url = it.optString("url"),
                    size = it.optLong("size"),
                    totalSize = it.optLong("totalSize"),
                    sha1 = it.optString("sha1")
                )
            }

            // downloads
            val downloadsObj = json.optObject("downloads")
            val downloads = Downloads(
                client = downloadsObj?.optObject("client")?.let { parseArtifact(it) },
                clientMappings = downloadsObj?.optObject("client_mappings")?.let { parseArtifact(it) },
                server = downloadsObj?.optObject("server")?.let { parseArtifact(it) },
                serverMappings = downloadsObj?.optObject("server_mappings")?.let { parseArtifact(it) }
            )

            val javaVersion = json.optObject("javaVersion")?.optInt("majorVersion")

            val logging = json.optObject("logging")?.optObject("client")?.let {
                LoggingConfig(
                    file = parseArtifact(it.optObject("file")!!),
                    argument = it.optString("argument"),
                    type = it.optString("type", "log4j2-xml")
                )
            }

            return VersionMeta(
                id = versionId,
                inheritsFrom = inheritsFrom,
                mainClass = json.optString("mainClass"),
                minecraftArguments = minecraftArguments,
                arguments = arguments,
                libraries = libraries,
                assetIndex = assetIndex,
                assets = json.optString("assets", "legacy"),
                downloads = downloads,
                javaVersion = javaVersion,
                logging = logging,
                type = json.optString("type", "release")
            )
        }

        private fun parseArguments(obj: JsonObject): Arguments {
            val game = (obj.optArray("game")?.iterator()?.asSequence()?.map { Arg.from(it) }?.toList()) ?: emptyList()
            val jvm = (obj.optArray("jvm")?.iterator()?.asSequence()?.map { Arg.from(it) }?.toList()) ?: emptyList()
            return Arguments(game, jvm)
        }

        private fun parseLibrary(obj: JsonObject): Library {
            val rules = (obj.optArray("rules")?.iterator()?.asSequence()
                ?.filterIsInstance<JsonObject>()
                ?.map { parseRule(it) }?.toList()) ?: emptyList()

            val natives = obj.optObject("natives")?.entries
                ?.associate { (k, v) -> k to (v as? com.indielauncher.core.util.JsonString)?.value ?: v.asString() }
                ?: emptyMap()

            val downloadsObj = obj.optObject("downloads")
            val artifact = downloadsObj?.optObject("artifact")?.let { parseArtifact(it) }
            val classifiers = downloadsObj?.optObject("classifiers")?.entries
                ?.associate { (k, v) -> k to parseArtifact(v.asObject()) }
            val downloads = if (artifact != null || classifiers != null) {
                LibraryDownloads(artifact, classifiers)
            } else null

            return Library(
                name = obj.optString("name"),
                url = obj.optString("url", MOJANG_LIBRARIES),
                rules = rules,
                natives = natives,
                extractExcludes = obj.optArray("extract")?.optArray("exclude")?.asStringList() ?: emptyList(),
                downloads = downloads,
                sha1 = obj.optString("sha1").ifBlank { null }
            )
        }

        private fun parseRule(obj: JsonObject): Rule {
            val action = obj.optString("action", Rule.ALLOW)
            val osObj = obj.optObject("os")
            val os = osObj?.let {
                OsRule(
                    name = it.optString("name").ifBlank { null },
                    version = it.optString("version").ifBlank { null },
                    arch = it.optString("arch").ifBlank { null }
                )
            }
            val features = obj.optObject("features")?.entries
                ?.associate { (k, v) -> k to v.asBoolean() }
            return Rule(action, os, features)
        }

        private fun parseArtifact(obj: JsonObject): ArtifactInfo =
            ArtifactInfo(
                url = obj.optString("url"),
                sha1 = obj.optString("sha1"),
                size = obj.optLong("size")
            )
    }
}
