package com.indielauncher.core.mods

import com.indielauncher.core.util.HttpClient
import com.indielauncher.core.util.JsonObject
import com.indielauncher.core.util.JsonParser
import com.indielauncher.core.util.Logger
import java.io.File

/**
 * Forge 安装器。
 *
 * Forge 1.13+ 使用新的 installer/profile 机制：installer 会生成
 * launch metadata 与 processors（需要执行部分 Java 代码来完成安装）。
 *
 * 由于 processors 执行复杂且与具体游戏版本强耦合，这里提供两种策略：
 *   1. 直接下载官方 installer 并用 headless 模式运行（推荐，最兼容）
 *   2. 对于新版（1.20.1+），解析 installer 的 version.json 与 processors
 *
 * 官方 maven：https://maven.minecraftforge.net/net/minecraftforge/forge/
 * 版本列表（第三方镜像）：https://files.minecraftforge.net/net/minecraftforge/forge/
 */
class ForgeInstaller(
    private val versionsDir: File,
    private val librariesDir: File,
    private val javaBinary: String = "java",
    private val http: HttpClient = HttpClient()
) {

    /** 获取某个 MC 版本可用的 Forge 版本列表。 */
    fun fetchForgeVersions(mcVersion: String): List<ForgeVersion> {
        // Forge 官方提供的版本清单（较新版本）
        val url = "https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml"
        return try {
            val text = http.downloadText(url)
            // 解析 <version>mcVersion-...</version>
            Regex("""<version>($mcVersion-[^<]+)</version>""")
                .findAll(text)
                .map { ForgeVersion(it.groupValues[1], "universal") }
                .toList()
                .reversed()
        } catch (t: Throwable) {
            Logger.w("Forge", "无法获取 Forge 版本列表: ${t.message}")
            emptyList()
        }
    }

    /**
     * 安装 Forge。
     *
     * 生成新版本 id：forge-<forgeVersion>
     */
    fun install(mcVersion: String, forgeVersion: String): String {
        val fullVersion = if (forgeVersion.contains("-")) forgeVersion else "$mcVersion-$forgeVersion"
        val newVersionId = "forge-$fullVersion"

        // 下载 installer
        val installerUrl = "https://maven.minecraftforge.net/net/minecraftforge/forge/$fullVersion/forge-$fullVersion-installer.jar"
        val installerJar = File(versionsDir, "forge/$fullVersion/forge-installer.jar")
        installerJar.parentFile?.mkdirs()

        Logger.i("Forge", "下载 installer: $installerUrl")
        http.download(url = installerUrl, dest = installerJar)

        // 用 headless 模式运行 installer
        // 不同版本参数不同：
        // 旧版（1.12-）：--installClient=<mcDir>
        // 新版（1.13+）：client -mcversion <mc> -dir <dir>
        val targetDir = File(versionsDir, newVersionId)
        targetDir.mkdirs()

        val process = try {
            val cmd = listOf(
                javaBinary, "-jar", installerJar.absolutePath,
                "--installClient", targetDir.parentFile.absolutePath
            )
            Logger.i("Forge", "运行: ${cmd.joinToString(" ")}")
            ProcessBuilder(cmd).directory(targetDir).start()
        } catch (t: Throwable) {
            // 新版参数
            val cmd = listOf(
                javaBinary, "-jar", installerJar.absolutePath,
                "client", "-mcversion", mcVersion, "-dir", targetDir.absolutePath
            )
            Logger.i("Forge", "重试新版参数: ${cmd.joinToString(" ")}")
            ProcessBuilder(cmd).directory(targetDir).start()
        }

        val rc = process.waitFor()
        if (rc != 0) {
            val err = process.errorStream.bufferedReader().readText()
            throw IllegalStateException("Forge installer 失败 (exit=$rc): $err")
        }

        // installer 通常会生成 <mcVersion>-forge-<forgeVersion> 目录
        val expected = File(versionsDir, "$mcVersion-forge-$fullVersion")
        if (expected.exists()) {
            return "$mcVersion-forge-$fullVersion"
        }
        return newVersionId
    }

    /** 1.13+ 新版：解析 installer 中的 version.json，准备 processors 执行。 */
    fun prepareProcessors(installerJar: File, versionJsonOut: File) {
        // 解压 installer，读取 version.json 与 data
        // processors 是 List<Processor{jar, classpath, args, outputs}>
        // 实现上需按官方 installer 逻辑执行，这里仅预留接口
        Logger.i("Forge", "准备 processors（新版 Forge 需要 JVM 内执行 processors）")
    }

    data class ForgeVersion(val fullVersion: String, val type: String)

    companion object {
        const val FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge/"
    }
}
