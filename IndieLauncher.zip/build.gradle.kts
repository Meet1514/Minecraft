// Top-level build file
plugins {
    id("com.android.application") version "8.7.0" apply false
    id("com.android.library") version "8.7.0" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("java-library") apply false
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}
