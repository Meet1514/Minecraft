package com.indielauncher.runtime

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.indielauncher.R
import com.indielauncher.ui.MainActivity

/**
 * 游戏运行时前台服务。
 *
 * Android 12+ 对后台进程有严格限制（phantom process killer），
 * 游戏属于长时运行任务，必须以前台服务形式托管，否则容易被系统回收。
 */
class RuntimeForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "indielauncher_runtime"
        const val NOTIFICATION_ID = 1001

        fun start(context: Context, profileName: String) {
            val intent = Intent(context, RuntimeForegroundService::class.java).apply {
                putExtra("profile_name", profileName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, RuntimeForegroundService::class.java))
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val profileName = intent?.getStringExtra("profile_name") ?: "Minecraft"
        val notification = buildNotification(profileName)
        startForeground(NOTIFICATION_ID, notification)
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "游戏运行",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "游戏运行时保持活跃"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(profileName: String): android.app.Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("IndieLauncher")
            .setContentText("正在运行：$profileName")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
