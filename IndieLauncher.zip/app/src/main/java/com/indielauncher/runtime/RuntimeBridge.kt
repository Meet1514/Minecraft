package com.indielauncher.runtime

import android.util.Log

/**
 * JNI 桥接到 runtime-ffi 的 C 层。
 *
 * 自有桥接层，只暴露稳定 ABI，不复制 Pojav/FCL 的 JNI 实现。
 * 负责加载 JRE 的 libjli.so 并通过 JLI_Launch 启动游戏 JVM。
 */
object RuntimeBridge {

    private const val TAG = "RuntimeBridge"

    init {
        try {
            System.loadLibrary("indie_runtime")
            Log.i(TAG, "indie_runtime loaded")
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to load indie_runtime", t)
        }
    }

    /**
     * 加载 JRE 的 libjli.so。返回 0 表示成功。
     * 非 0 的返回值含义：
     *  -1: jliPath 为 null
     *  -2: 无法获取字符串
     *  -3: dlopen 失败（详见 logcat）
     *  -4: dlsym JLI_Launch 失败
     */
    @JvmStatic
    external fun nativeLoadJvmLibrary(jliPath: String): Int

    /** 通过 JLI_Launch 启动游戏 JVM。 */
    @JvmStatic
    external fun nativeJliLaunch(args: Array<String>, progName: String): Int

    /** 检查目录是否为完整 JRE。 */
    @JvmStatic
    external fun nativeIsValidJre(runtimeDir: String): Boolean

    /** 设置 LD_LIBRARY_PATH。 */
    @JvmStatic
    external fun nativeSetLibraryPath(path: String)

    /** 探测可用 ABI。 */
    fun currentAbi(): String {
        val abis = android.os.Build.SUPPORTED_ABIS
        return if (abis.isNotEmpty()) abis[0] else "arm64-v8a"
    }
}
