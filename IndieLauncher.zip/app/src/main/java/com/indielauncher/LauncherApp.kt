package com.indielauncher

import android.app.Application
import com.indielauncher.core.game.GameRepository
import com.indielauncher.core.util.AppDirectories
import com.indielauncher.core.util.PreferencesStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * 应用入口。负责初始化目录结构、全局协程作用域与核心仓库。
 *
 * 设计参考 FCL / Pojav 的"先准备环境、再进 UI"思路，但全部自研实现。
 */
class LauncherApp : Application() {

    val applicationScope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var directories: AppDirectories
        private set

    lateinit var preferences: PreferencesStore
        private set

    lateinit var gameRepository: GameRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        directories = AppDirectories(this)
        directories.ensureDirectories()

        preferences = PreferencesStore(this)

        gameRepository = GameRepository(
            rootDir = directories.gamesDir,
            librariesDir = directories.librariesDir,
            assetsDir = directories.assetsDir,
            nativesDir = directories.nativesDir,
            runtimeDir = directories.runtimeDir,
            preferences = preferences
        )
    }

    override fun onTerminate() {
        super.onTerminate()
        applicationScope.cancel()
    }

    companion object {
        @Volatile
        lateinit var instance: LauncherApp
            private set
    }
}
