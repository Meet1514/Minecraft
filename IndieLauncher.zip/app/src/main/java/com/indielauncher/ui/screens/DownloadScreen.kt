package com.indielauncher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

/**
 * 下载页面。三个 Tab：
 *   - 游戏版本：原版 / Forge / Fabric / Quilt
 *   - Mod：从 Modrinth / CurseForge 搜索并安装
 *   - 光影 / 资源包：导入或下载
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadScreen(modifier: Modifier = Modifier) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("游戏版本", "Mod", "光影 / 资源包")

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            tabs.forEachIndexed { i, t ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = { Text(t) }
                )
            }
        }

        when (tab) {
            0 -> GameVersionTab()
            1 -> ModsTab()
            2 -> ContentTab()
        }
    }
}

@Composable
private fun GameVersionTab() {
    val scope = rememberCoroutineScope()
    var selectedType by remember { mutableStateOf("原版") }
    var versions by remember { mutableStateOf<List<com.indielauncher.core.game.VersionManifest.VersionRef>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }

    val types = listOf("原版", "Forge", "Fabric", "Quilt")

    Column(modifier = Modifier.padding(16.dp)) {
        // 类型选择
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            types.forEach { type ->
                Button(
                    onClick = { selectedType = type },
                    modifier = Modifier.height(36.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = if (selectedType == type)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Text(type, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // 拉取版本列表
        Button(
            onClick = {
                scope.launch {
                    isLoading = true
                    runCatching {
                        versions = com.indielauncher.LauncherApp.instance.gameRepository.manifest.fetch()
                            .filter { ref ->
                                when (selectedType) {
                                    "原版" -> true
                                    else -> true // Forge/Fabric/Quilt 版本需先装原版，这里全部列出
                                }
                            }
                            .take(50)
                    }
                    isLoading = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (isLoading) "加载中..." else "刷新版本列表")
        }

        Spacer(Modifier.height(16.dp))

        // 下载进度
        val progress by com.indielauncher.LauncherApp.instance.gameRepository.downloader.globalProgress.collectAsState()
        if (progress.totalTasks > 0) {
            LinearProgressIndicator(
                progress = { progress.fraction },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "${progress.completedCount}/${progress.totalTasks} · ${(progress.fraction * 100).toInt()}%",
                color = Color.Gray,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(16.dp))
        }

        // 版本列表
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(versions) { ref ->
                VersionRow(ref = ref) { versionId ->
                    scope.launch {
                        val repo = com.indielauncher.LauncherApp.instance.gameRepository
                        val plan = repo.installer.plan(versionId)
                        repo.downloader.submitAll(plan.tasks)
                        // 安装 loader 的逻辑根据 selectedType 分支
                    }
                }
            }
        }
    }
}

@Composable
private fun VersionRow(
    ref: com.indielauncher.core.game.VersionManifest.VersionRef,
    onInstall: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(ref.id, fontWeight = FontWeight.Medium)
                Text(
                    ref.type,
                    fontSize = 12.sp,
                    color = when (ref.type) {
                        "release" -> Color(0xFF4CAF50)
                        "snapshot" -> Color(0xFFFF9800)
                        else -> Color.Gray
                    }
                )
            }
            Button(onClick = { onInstall(ref.id) }) {
                Text("安装")
            }
        }
    }
}

@Composable
private fun ModsTab() {
    var query by remember { mutableStateOf("") }
    var loader by remember { mutableStateOf("fabric") }
    var results by remember { mutableStateOf<List<com.indielauncher.core.repository.ContentRepository.ContentItem>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Column(modifier = Modifier.padding(16.dp)) {
        // 搜索框
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("搜索 Mod") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = TextFieldDefaults.outlinedTextFieldColors()
        )

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("fabric", "forge", "quilt").forEach { l ->
                Button(
                    onClick = { loader = l },
                    modifier = Modifier.height(36.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = if (loader == l)
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Text(l.uppercase(), fontSize = 12.sp)
                }
            }

            Button(
                onClick = {
                    scope.launch {
                        results = com.indielauncher.LauncherApp.instance.gameRepository.content.searchMods(
                            query = query, loader = when (loader) {
                                "fabric" -> com.indielauncher.core.mods.ModLoader.FABRIC
                                "forge" -> com.indielauncher.core.mods.ModLoader.FORGE
                                "quilt" -> com.indielauncher.core.mods.ModLoader.QUILT
                                else -> null
                            }
                        )
                    }
                },
                modifier = Modifier.height(36.dp)
            ) {
                Text("搜索")
            }
        }

        Spacer(Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results) { item ->
                when (item) {
                    is com.indielauncher.core.repository.ContentRepository.ContentItem.ModrinthItem -> {
                        ModResultRow(
                            title = item.title,
                            description = item.description,
                            author = item.author,
                            downloads = item.downloads
                        ) { /* 安装 */ }
                    }
                    is com.indielauncher.core.repository.ContentRepository.ContentItem.CurseForgeItem -> {
                        ModResultRow(
                            title = item.name,
                            description = item.summary,
                            author = item.authors.joinToString(),
                            downloads = item.downloads
                        ) { /* 安装 */ }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModResultRow(
    title: String,
    description: String,
    author: String,
    downloads: Long,
    onInstall: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(
                    description,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    maxLines = 2
                )
                Text(
                    "$author · ${downloads / 1000}K 下载",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            Button(onClick = onInstall) {
                Text("安装")
            }
        }
    }
}

@Composable
private fun ContentTab() {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("光影包与资源包", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "把 .zip 文件放到对应 profile 的 shaderpacks/ 或 resourcepacks/ 目录即可。",
            color = Color.Gray,
            fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { /* 打开文件选择器 */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("从本地导入")
        }
    }
}
