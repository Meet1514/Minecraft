package com.indielauncher.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.indielauncher.core.util.Os
import com.indielauncher.ui.screens.MainScreen
import com.indielauncher.ui.theme.IndieLauncherTheme

/**
 * 主 Activity。Compose 单 Activity 架构。
 *
 * 启动时把 Android ABI 注入核心层的 Os 工具，让 natives 选择正确。
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 注入 Android 运行时信息
        Os.isAndroid = true
        Os.androidAbi = android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64-v8a"

        setContent {
            IndieLauncherTheme(darkTheme = true) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainApp()
                }
            }
        }
    }
}

@Composable
fun MainApp() {
    MainScreen()
}
