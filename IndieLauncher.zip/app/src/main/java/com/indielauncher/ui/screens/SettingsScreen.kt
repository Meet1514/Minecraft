package com.indielauncher.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 设置页面。
 */
@Composable
fun SettingsScreen(modifier: Modifier = Modifier) {
    var memoryMb by remember { androidx.compose.runtime.mutableFloatStateOf(2048f) }
    var renderer by remember { mutableStateOf("zink") }
    var telemetry by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text(
            "设置",
            fontSize = 22.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )

        Spacer(Modifier.size(16.dp))

        // 内存
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("最大内存：${memoryMb.toInt()} MB", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                Spacer(Modifier.size(8.dp))
                Slider(
                    value = memoryMb,
                    onValueChange = { memoryMb = it },
                    valueRange = 512f..8192f,
                    steps = 15
                )
            }
        }

        Spacer(Modifier.size(12.dp))

        // 渲染后端
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("渲染后端", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                Spacer(Modifier.size(8.dp))
                listOf("zink" to "Zink (推荐)", "gl4es" to "GL4ES", "egl" to "直接 EGL").forEach { (id, name) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Switch(
                            checked = renderer == id,
                            onCheckedChange = { renderer = id }
                        )
                        Spacer(Modifier.size(8.dp))
                        Text(name)
                    }
                }
            }
        }

        Spacer(Modifier.size(12.dp))

        // 诊断日志
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.size(8.dp))
                    Text("崩溃诊断", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                }
                Spacer(Modifier.size(8.dp))
                Text(
                    "启动时自动记录环境快照，崩溃后提供安全模式恢复。",
                    fontSize = 12.sp,
                    color = androidx.compose.ui.graphics.Color.Gray
                )
                Spacer(Modifier.size(8.dp))
                Switch(
                    checked = telemetry,
                    onCheckedChange = { telemetry = it }
                )
                Spacer(Modifier.size(8.dp))
                Text(if (telemetry) "已启用本地诊断日志" else "本地诊断日志已关闭")
            }
        }

        Spacer(Modifier.size(12.dp))

        Button(
            onClick = { /* 打开 OSS Licenses 页面 */ },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("开源许可")
        }
    }
}
