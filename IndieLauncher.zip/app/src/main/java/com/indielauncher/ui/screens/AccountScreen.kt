package com.indielauncher.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 账号页面。支持离线账号与微软正版登录。
 */
@Composable
fun AccountScreen(modifier: Modifier = Modifier) {
    var showOfflineDialog by remember { mutableStateOf(false) }
    val accounts = remember { com.indielauncher.LauncherApp.instance.gameRepository.accounts.list() }

    LazyColumn(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "账号",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        items(accounts) { account ->
            AccountRow(
                name = account.username,
                type = if (account.isOffline()) "离线" else "微软",
                uuid = account.uuid.toString()
            )
        }

        item {
            Button(
                onClick = { showOfflineDialog = true },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.PersonOutline, null)
                Spacer(Modifier.size(8.dp))
                Text("添加离线账号")
            }
        }

        item {
            Button(
                onClick = {
                    // 启动微软登录 Activity
                    val ctx = com.indielauncher.LauncherApp.instance
                    android.content.Intent(ctx, com.indielauncher.auth.MicrosoftLoginActivity::class.java)
                        .also { ctx.startActivity(it) }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Person, null)
                Spacer(Modifier.size(8.dp))
                Text("微软正版登录")
            }
        }
    }

    if (showOfflineDialog) {
        OfflineAccountDialog(
            onDismiss = { showOfflineDialog = false },
            onConfirm = { username ->
                val acc = com.indielauncher.core.auth.OfflineAccountFactory.create(username)
                com.indielauncher.LauncherApp.instance.gameRepository.accounts.add(acc)
                showOfflineDialog = false
            }
        )
    }
}

@Composable
private fun AccountRow(name: String, type: String, uuid: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(Modifier.size(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "$type · ${uuid.take(8)}...",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
private fun OfflineAccountDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var username by remember { mutableStateOf("") }
    androidx.compose.ui.window.Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("添加离线账号", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(16.dp))
                TextField(
                    value = username,
                    onValueChange = { if (it.length <= 16) username = it },
                    label = { Text("游戏名（最多16字符）") },
                    singleLine = true
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.End) {
                    Button(onClick = onDismiss) { Text("取消") }
                    Spacer(Modifier.size(8.dp))
                    Button(
                        onClick = { if (username.isNotBlank()) onConfirm(username) },
                        enabled = username.isNotBlank()
                    ) {
                        Text("确认")
                    }
                }
            }
        }
    }
}
