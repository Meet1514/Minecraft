package com.indielauncher.auth

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.indielauncher.core.auth.Account
import com.indielauncher.core.auth.AccountStore
import com.indielauncher.core.auth.MicrosoftAccount

/**
 * Android 安全的账号存储。
 *
 * 使用 Jetpack Security 的 EncryptedSharedPreferences（基于 Android Keystore），
 * 敏感字段（accessToken / refreshToken）加密存储。
 *
 * 调研报告强调：账号流程必须以 OAuth2/MSAL 状态机实现，绝不能保存明文密码。
 */
class SecureAccountStore(context: Context) {

    private val masterKey: MasterKey = MasterKey.Builder(context, MasterKey.DEFAULT_MASTHIC_KEY_ALIAS)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "indielauncher_accounts",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val fallback: AccountStore = AccountStore(
        context.filesDir
    )

    /** 保存微软账号（token 加密）。 */
    fun saveMicrosoft(account: MicrosoftAccount) {
        prefs.edit().apply {
            putString("ms.${account.id}.username", account.username)
            putString("ms.${account.id}.uuid", account.uuid.toString())
            putString("ms.${account.id}.accessToken", account.accessToken)
            putString("ms.${account.id}.refreshToken", account.refreshToken)
            putLong("ms.${account.id}.expiresAt", account.expiresAtMs)
            apply()
        }
        fallback.add(account)
    }

    fun getMicrosoft(id: String): MicrosoftAccount? {
        if (!prefs.contains("ms.$id.accessToken")) return null
        return MicrosoftAccount(
            id = id,
            username = prefs.getString("ms.$id.username", "") ?: "",
            uuid = java.util.UUID.fromString(prefs.getString("ms.$id.uuid", "") ?: ""),
            accessToken = prefs.getString("ms.$id.accessToken", "") ?: "",
            refreshToken = prefs.getString("ms.$id.refreshToken", "") ?: "",
            expiresAtMs = prefs.getLong("ms.$id.expiresAt", 0L)
        )
    }

    fun remove(id: String) {
        prefs.edit().apply {
            remove("ms.$id.username")
            remove("ms.$id.uuid")
            remove("ms.$id.accessToken")
            remove("ms.$id.refreshToken")
            remove("ms.$id.expiresAt")
            apply()
        }
        fallback.remove(id)
    }

    fun allAccounts(): List<Account> = fallback.list()

    fun setActive(id: String) {
        prefs.edit().putString("active_account_id", id).apply()
    }

    fun getActive(): Account? {
        val id = prefs.getString("active_account_id", null) ?: return fallback.getActive()
        // 判断类型
        return if (id.startsWith("ms-")) getMicrosoft(id) else fallback.getActive()
    }
}
