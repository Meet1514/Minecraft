package com.indielauncher.auth

import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.browser.customtabs.CustomTabsIntent
import com.indielauncher.core.auth.MicrosoftAuth
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 微软账号登录 Activity。
 *
 * 流程：通过 Chrome Custom Tabs 打开授权页面，用户完成登录后，
 * 通过重定向 URI 回调，捕获授权码，换取 token。
 *
 * 必须在 https://portal.azure.com/ 注册应用，账户类型选
 * "多租户 + 个人微软账户"，并启用公共客户端流。
 *
 * 设计参考 FCL / Pojav 的 OAuth2 设备 code / authorization code 流程。
 */
class MicrosoftLoginActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private lateinit var auth: MicrosoftAuth

    companion object {
        // 替换为你自己的 Azure 应用 Client ID
        const val CLIENT_ID = "00000000-0000-0000-0000-000000000000"
        const val REDIRECT_URI = "https://login.microsoftonline.com/common/oauth2/nativeclient"
        const val RESPONSE_TYPE = "code"
        const val SCOPE = "Xboxlive.signin offline_access"

        private const val TAG = "MicrosoftLogin"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = MicrosoftAuth(CLIENT_ID)

        if (CLIENT_ID == "00000000-0000-0000-0000-000000000000") {
            Log.w(TAG, "请先配置 Azure 应用的 Client ID")
            finish()
            return
        }

        startDeviceCodeFlow()
    }

    /** 使用设备代码流（无需重定向，手机端更友好）。 */
    private fun startDeviceCodeFlow() {
        scope.launch {
            try {
                val resp = auth.requestDeviceCode()
                // 用 Custom Tabs 打开授权页
                val uri = Uri.parse(resp.verificationUri)
                runOnUiThread {
                    val tabs = CustomTabsIntent.Builder().build()
                    tabs.launchUrl(this@MicrosoftLoginActivity, uri)
                }
                // 轮询
                val msa = auth.pollForToken(resp.deviceCode, resp.interval)
                val xbl = auth.exchangeXbl(msa.accessToken)
                val xsts = auth.exchangeXsts(xbl.token)
                val mcToken = auth.loginMinecraft(xsts.token, xsts.uhs)
                val profile = auth.fetchProfile(mcToken)

                // 保存账号
                val account = com.indielauncher.core.auth.MicrosoftAccount(
                    id = "ms-" + profile.uuid.toString(),
                    username = profile.username,
                    uuid = profile.uuid,
                    accessToken = mcToken,
                    refreshToken = msa.refreshToken,
                    expiresAtMs = System.currentTimeMillis() + msa.expiresIn * 1000
                )
                // 通知 MainActivity 保存
                val result = Intent().apply {
                    putExtra("account_id", account.id)
                    putExtra("username", account.username)
                    putExtra("uuid", account.uuid.toString())
                    putExtra("access_token", account.accessToken)
                    putExtra("refresh_token", account.refreshToken)
                    putExtra("expires_at", account.expiresAtMs)
                }
                setResult(RESULT_OK, result)
                finish()
            } catch (t: Throwable) {
                Log.e(TAG, "登录失败", t)
                setResult(RESULT_CANCELED)
                finish()
            }
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // 处理重定向回调（authorization code 流程）
        val data = intent?.data
        if (data != null && data.toString().startsWith(REDIRECT_URI)) {
            val code = data.getQueryParameter("code")
            if (code != null) {
                // 用 code 换 token
                // ...（此处省略，与设备代码流类似）
            }
        }
    }
}
