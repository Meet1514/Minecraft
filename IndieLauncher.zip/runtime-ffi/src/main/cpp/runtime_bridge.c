#include <jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include "runtime_bridge.h"
#include "dir_utils.h"

#define TAG "IndieRuntime"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

/* 缓存已加载的 JLI 句柄。 */
static void *g_jli_handle = NULL;

/* JLI_Launch 的函数指针类型。 */
typedef int (JLI_LaunchFunc)(
    int argc, char **argv,
    int jargc, const char **jargv,
    int appclassc, const char **appclassv,
    const char *fullversion,
    const char *dotversion,
    const char *pname,
    const char *lname,
    jboolean javaargs,
    jboolean cpwildcard,
    jclass mainClass,
    jboolean ret,
    char *splashpath);

static JLI_LaunchFunc *g_jli_launch = NULL;

JNIEXPORT jint JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeLoadJvmLibrary(
    JNIEnv *env, jclass clazz, jstring jliPath)
{
    if (jliPath == NULL) {
        LOGE("nativeLoadJvmLibrary: jliPath is NULL");
        return -1;
    }
    const char *cpath = (*env)->GetStringUTFChars(env, jliPath, NULL);
    if (cpath == NULL) return -2;

    LOGI("nativeLoadJvmLibrary: loading %s", cpath);

    if (g_jli_handle != NULL) {
        dlclose(g_jli_handle);
        g_jli_handle = NULL;
        g_jli_launch = NULL;
    }

    g_jli_handle = dlopen(cpath, RTLD_LAZY | RTLD_GLOBAL);
    if (g_jli_handle == NULL) {
        LOGE("dlopen failed: %s", dlerror());
        (*env)->ReleaseStringUTFChars(env, jliPath, cpath);
        return -3;
    }

    g_jli_launch = (JLI_LaunchFunc *) dlsym(g_jli_handle, "JLI_Launch");
    if (g_jli_launch == NULL) {
        LOGE("dlsym JLI_Launch failed: %s", dlerror());
        dlclose(g_jli_handle);
        g_jli_handle = NULL;
        (*env)->ReleaseStringUTFChars(env, jliPath, cpath);
        return -4;
    }

    (*env)->ReleaseStringUTFChars(env, jliPath, cpath);
    LOGI("nativeLoadJvmLibrary: OK");
    return 0;
}

JNIEXPORT jint JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeJliLaunch(
    JNIEnv *env, jclass clazz, jobjectArray args, jstring progName)
{
    if (g_jli_launch == NULL) {
        LOGE("nativeJliLaunch: JLI_Launch not loaded");
        return -10;
    }
    if (args == NULL) {
        LOGE("nativeJliLaunch: args is NULL");
        return -11;
    }

    jsize argc = (*env)->GetArrayLength(env, args);
    char **argv = (char **) calloc(argc + 1, sizeof(char *));
    if (argv == NULL) return -12;

    for (jsize i = 0; i < argc; i++) {
        jstring js = (jstring) (*env)->GetObjectArrayElement(env, args, i);
        const char *c = (*env)->GetStringUTFChars(env, js, NULL);
        argv[i] = strdup(c ? c : "");
        (*env)->ReleaseStringUTFChars(env, js, c);
        (*env)->DeleteLocalRef(env, js);
    }
    argv[argc] = NULL;

    const char *pname = progName != NULL
        ? (*env)->GetStringUTFChars(env, progName, NULL)
        : "java";

    LOGI("nativeJliLaunch: launching with %d args", argc);

    int rc = g_jli_launch(
        (int) argc, argv,
        0, NULL,
        0, NULL,
        "1.0", "1.0",
        pname, "IndieLauncher",
        JNI_FALSE, JNI_FALSE,
        NULL, JNI_FALSE,
        NULL);

    if (pname != NULL) (*env)->ReleaseStringUTFChars(env, progName, pname);
    for (jsize i = 0; i < argc; i++) free(argv[i]);
    free(argv);

    LOGI("nativeJliLaunch: returned %d", rc);
    return rc;
}

JNIEXPORT jboolean JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeIsValidJre(
    JNIEnv *env, jclass clazz, jstring runtimeDir)
{
    if (runtimeDir == NULL) return JNI_FALSE;
    const char *dir = (*env)->GetStringUTFChars(env, runtimeDir, NULL);
    if (dir == NULL) return JNI_FALSE;

    int valid = 0;
    if (dir_contains_jvm(dir)) valid = 1;

    (*env)->ReleaseStringUTFChars(env, runtimeDir, dir);
    return valid ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeSetLibraryPath(
    JNIEnv *env, jclass clazz, jstring path)
{
    if (path == NULL) return;
    const char *p = (*env)->GetStringUTFChars(env, path, NULL);
    if (p == NULL) return;

    /* Android 上 LD_LIBRARY_PATH 对 linker namespace 影响有限，
     * 这里仅作兜底；真正生效的是 java.library.path 与 dlopen 顺序。 */
    setenv("LD_LIBRARY_PATH", p, 1);
    LOGI("LD_LIBRARY_PATH = %s", p);

    (*env)->ReleaseStringUTFChars(env, path, p);
}
