#ifndef INDIE_RUNTIME_BRIDGE_H
#define INDIE_RUNTIME_BRIDGE_H

#include <jni.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * 自有 JNI 桥接层。
 *
 * 设计原则：
 *  - 只暴露稳定的 C ABI，供 Android/Kotlin 侧调用。
 *  - 不直接复制 Pojav / FCL 的 JNI 实现；仅参考其架构思路。
 *  - JRE、LWJGL/GLFW、OpenAL、GL backend 均作为可替换运行时组件。
 */

/* 加载 JRE 的 libjli.so，并准备 JavaVM 选项。返回 0 表示成功。 */
JNIEXPORT jint JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeLoadJvmLibrary(
    JNIEnv *env, jclass clazz, jstring jliPath);

/* 通过 JLI_Launch 启动游戏 JVM。参数为类 UNIX 风格 argv。 */
JNIEXPORT jint JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeJliLaunch(
    JNIEnv *env, jclass clazz, jobjectArray args, jstring progName);

/* 获取当前 ABI 名（armeabi-v7a / arm64-v8a / x86_64）。 */
JNIEXPORT jstring JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeGetAbi(JJNIEnv *env, jclass clazz);

/* 探测给定目录是否为完整可用的 JRE（存在 libjvm.so / libjli.so）。 */
JNIEXPORT jboolean JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeIsValidJre(
    JNIEnv *env, jclass clazz, jstring runtimeDir);

/* 设置进程的 LD_LIBRARY_PATH。Android 侧应在 fork 前调用。 */
JNIEXPORT void JNICALL
Java_com_indielauncher_runtime_RuntimeBridge_nativeSetLibraryPath(
    JNIEnv *env, jclass clazz, jstring path);

#ifdef __cplusplus
}
#endif

#endif /* INDIE_RUNTIME_BRIDGE_H */
