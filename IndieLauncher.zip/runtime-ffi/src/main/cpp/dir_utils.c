#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>

#include "dir_utils.h"

static int file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

int dir_contains_jvm(const char *dir) {
    if (dir == NULL || dir[0] == '\0') return 0;

    char buf[1024];

    /* JLI 入口，用于 JLI_Launch 启动。 */
    snprintf(buf, sizeof(buf), "%s/lib/%s/libjli.so",
             dir, "jli");
    if (file_exists(buf)) return 1;

    snprintf(buf, sizeof(buf), "%s/lib/server/libjvm.so", dir);
    if (file_exists(buf)) return 1;

    snprintf(buf, sizeof(buf), "%s/lib/client/libjvm.so", dir);
    if (file_exists(buf)) return 1;

    /* arm64-v8a / arm64 直接平铺（部分 Android 移植版布局）。 */
    snprintf(buf, sizeof(buf), "%s/lib/libjvm.so", dir);
    if (file_exists(buf)) return 1;

    return 0;
}
