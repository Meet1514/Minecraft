#ifndef INDIE_DIR_UTILS_H
#define INDIE_DIR_UTILS_H

#include <jni.h>

/* 检查目录是否为可用 JRE：依次尝试常见路径。 */
int dir_contains_jvm(const char *dir);

#endif
